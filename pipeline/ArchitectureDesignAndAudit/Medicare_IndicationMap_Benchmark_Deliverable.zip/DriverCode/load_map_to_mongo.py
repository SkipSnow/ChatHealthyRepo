"""One-shot: load the 750-record Pass-3 map from scratch into a clearly-named TEST
collection on the pipeline cluster (never production). Idempotent (upsert by set_id).
Identity pipelineEditor, cluster ChatHealthyDataPipelines (hardcoded literals)."""
import os
import sys
import json
import pathlib

ROOT = pathlib.Path(r"c:\CHATHealthyLLC")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "ChatHealthyLib" / "src"))
for line in (ROOT / ".env").read_text(encoding="utf-8", errors="replace").splitlines():
    if "=" in line and not line.strip().startswith("#"):
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())

import time
from pymongo import ReplaceOne
from chathealthy_lib.mongo_utilities import ChatHealthyMongoUtilities
from pipeline.run_lifecycle.cluster_lifecycle_manager import ClusterLifecycleManager

SCR = ROOT / "_oneshots" / "medicare_benchmark" / "harness" / "pass3_local_scratch" / "map_records.jsonl"
DB = "PipelinePublicHealthData"
COLL = "IndicationMap_pass3_local_test"

recs = [json.loads(l) for l in SCR.read_text(encoding="utf-8").splitlines() if l.strip()]
print(f"loading {len(recs)} map records -> {DB}.{COLL}", flush=True)

mgr = ClusterLifecycleManager(get_db_fn=None)
print("waking cluster ...", flush=True)
mgr.wake("ChatHealthyDataPipelines", job_id="pass3-load")
try:
    mgr.reserve("ChatHealthyDataPipelines", job_id="pass3-load", requester="pass3-load",
                expected_duration_minutes=120, reservation_class="human")
except Exception as e:  # noqa: BLE001
    print("reserve warn:", repr(e)[:150], flush=True)
coll = None
for i in range(40):
    try:
        conn = ChatHealthyMongoUtilities().getConnection("pipelineEditor", "ChatHealthyDataPipelines")
        coll = conn[DB][COLL]
        coll.count_documents({})
        break
    except Exception as e:  # noqa: BLE001
        print(f"attempt {i}: cluster not ready: {repr(e)[:90]}", flush=True)
        time.sleep(15)
if coll is None:
    print("GAVE UP: cluster not ready within the window", flush=True)
    sys.exit(2)
ops = [ReplaceOne({"set_id": r.get("set_id")}, r, upsert=True) for r in recs if r.get("set_id")]
res = coll.bulk_write(ops, ordered=False)
print(f"upserted={res.upserted_count} modified={res.modified_count} | collection count now = {coll.count_documents({})}", flush=True)
print(f"DB ADDRESS: cluster=ChatHealthyDataPipelines  db={DB}  collection={COLL}", flush=True)
