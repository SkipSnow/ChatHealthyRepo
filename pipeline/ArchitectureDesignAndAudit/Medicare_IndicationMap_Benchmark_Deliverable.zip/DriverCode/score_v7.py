"""v7 benchmark scorer (test plan v7 section 8). Read-only over results_v7/ + the three beds;
writes ONLY score_v7.py's output scores_v7.json and prints a compact summary. NO model/LLM calls
and NO network calls - all measures are computed from the persisted token/output records.

Measure math reuses the existing judges where sound (cited inline):
  - hallucination (out-of-catalog)  : judge_grid.py:45 / score_accumulated.py:58
  - coverage (>=1 indication)       : judge_grid.py:49  (refined here to >=1 indication AND >=1 code)
  - cross-model consensus agreement : judge_grid.py:56-68 / score_accumulated.py:42-51
  - long-context cost formula       : judge_grid.py:47 / score_accumulated.py:59-60
  - long-context rate caveat        : score_accumulated.py:11-15
"""
import json, math, pathlib, sys
from collections import defaultdict, Counter

R = pathlib.Path(r"c:\CHATHealthyLLC\_oneshots\medicare_benchmark\harness")
sys.path.insert(0, str(R))
import crosswalk as c  # c.CATALOG_CODES, c.MODELS  (BUILD ONLY - no model call on import)

RESULTS = R / "results_v7"
BATCH = 50
TOKEN_LIMIT_MARK = "token limit"  # substring of the gemini-3.8-flash null-output error

BEDS = {
    "bed1": "benchmark_sample.jsonl",
    "bed2": "benchmark_sample_v2.jsonl",
    "bed3": "benchmark_sample_v3_union.jsonl",
}
JUDGED_BEDS = ("bed1", "bed2")  # section 8: hallucination/coverage/schema over bed1 + bed2

# Long-context rate caveat table (score_accumulated.py:11-15). We cost with c.MODELS prices
# (the dated table pinned in crosswalk.py) as primary, and surface these as the caveat: the
# ~440K-token prompt is over every provider's 200K/272K threshold.
LONGCTX = {
    "openai:5.6-luna":  (0.40, 0.04, 1.80),   # luna long-context confirmed >272K
    "google:3.5-flite": (0.30, 0.03, 2.50),   # standard rate; >200K tier UNCONFIRMED
    "google:3.8-flash": (0.75, 0.075, 3.75),  # standard rate; >200K tier UNCONFIRMED
}


def load_bed(name):
    recs = [json.loads(l) for l in (R / BEDS[name]).read_text(encoding="utf-8").splitlines()
            if l.strip()]
    return recs  # record id == str(its 0-based index), per the runner


def codes_of(result):
    """All ICD-10 codes a single DrugResult emitted (judge_grid.py:38)."""
    return [cc["icd10_code"] for ind in result.get("indications", []) for cc in ind.get("codes", [])]


def main():
    partial_note = []
    beds = {name: load_bed(name) for name in BEDS}
    bed_sizes = {name: len(recs) for name, recs in beds.items()}
    # id -> record, per bed
    bed_rec = {name: {str(i): r for i, r in enumerate(recs)} for name, recs in beds.items()}

    # ---- load every result file ----
    files = sorted(RESULTS.glob("run__*.json"))
    unmappable = []
    # grouped[(key, p, bed, bi)] -> {rnd: dict}
    grouped = defaultdict(dict)
    all_files = []
    model_keys = []
    for f in files:
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
        except Exception as e:
            unmappable.append((f.name, f"unreadable: {e!r}"))
            continue
        key, p, bed, bi, rnd = d.get("key"), d.get("pass"), d.get("bed"), d.get("batch_index"), d.get("round")
        if key is None or bed not in BEDS or p is None or bi is None or rnd is None:
            unmappable.append((f.name, "missing key/pass/bed/batch/round"))
            continue
        grouped[(key, p, bed, bi)][rnd] = d
        all_files.append(d)
        if key not in model_keys:
            model_keys.append(key)
    model_keys = [m["key"] for m in c.MODELS if m["key"] in model_keys]  # stable registry order

    # ---- merge per (key,pass,bed): union results across rounds (later round fills drops) ----
    # merged[(key,p,bed)] -> {id: result}     (latest round wins on duplicate id)
    merged = {}
    # drop bookkeeping per key
    drop_stats = {k: dict(initial_drops=0, finally_lost=0, recovered=0,
                          token_limit_lost=0, null_batches=0, token_limit_batches=0,
                          attempted_batches=0) for k in model_keys}
    # expected full grid (to report pending/partial)
    full_grid = sum(math.ceil(bed_sizes[b] / BATCH) for b in BEDS) * 2 * len(model_keys)
    attempted = set()

    for (key, p, bed, bi), rounds in grouped.items():
        attempted.add((key, p, bed, bi))
        lo = bi * BATCH
        hi = min(lo + BATCH, bed_sizes[bed])
        expected = {str(i) for i in range(lo, hi)}
        # id -> result, ascending rounds so latest wins
        idmap = {}
        returned_by_round = {}
        err_by_round = {}
        for rnd in sorted(rounds):
            d = rounds[rnd]
            out = d.get("output")
            res = out["results"] if out else []
            got = set()
            for r in res:
                rid = r["id"]
                idmap[rid] = r
                got.add(rid)
            returned_by_round[rnd] = got
            err_by_round[rnd] = (d.get("meta") or {}).get("error")
        merged.setdefault((key, p, bed), {}).update(idmap)

        union_ret = set(idmap)
        r0_ret = returned_by_round.get(0, set())
        initial = expected - r0_ret
        finally_lost = expected - union_ret
        recovered = (initial & union_ret)
        ds = drop_stats[key]
        ds["attempted_batches"] += 1
        ds["initial_drops"] += len(initial)
        ds["finally_lost"] += len(finally_lost)
        ds["recovered"] += len(recovered)
        # null-output / token-limit classification
        max_rnd = max(rounds)
        last_err = err_by_round.get(max_rnd)
        if returned_by_round.get(max_rnd) == set() and last_err:
            ds["null_batches"] += 1
            if TOKEN_LIMIT_MARK in (last_err or "").lower():
                ds["token_limit_batches"] += 1
                ds["token_limit_lost"] += len(finally_lost)

    if full_grid - len(attempted) > 0:
        partial_note.append(f"{full_grid - len(attempted)} of {full_grid} (pass,bed,model,batch) "
                            f"cells not yet attempted - run appears PARTIAL (no DONE reached).")

    # ---- per-model codeset views ----
    # by_pass[(key,bed)][p] = {id: set(codes)}
    # union_pass[(key,bed)]  = {id: set(codes)}   (union across passes + rounds)
    by_pass = defaultdict(lambda: defaultdict(dict))
    union_pass = defaultdict(dict)
    judged_results = defaultdict(list)  # key -> list of result dicts over JUDGED_BEDS (both passes)
    returned_usage_summary = defaultdict(lambda: [0, 0])  # key -> [present, total] over judged

    for (key, p, bed), idmap in merged.items():
        for rid, r in idmap.items():
            cset = set(codes_of(r))
            by_pass[(key, bed)][p][rid] = cset
            u = union_pass[(key, bed)].setdefault(rid, set())
            u |= cset

    # ---- MEASURE 1 hallucination, 2 coverage, 4 schema (judged set = bed1+bed2, both passes) ----
    halluc = {}
    coverage = {}
    schema = {}
    for key in model_keys:
        allcodes, ooc = 0, 0
        n_results, n_covered = 0, 0
        conf_bad, rat_missing, usage_missing, n_ind = 0, 0, 0, 0
        for bed in JUDGED_BEDS:
            for p in (1, 2):
                idmap = merged.get((key, p, bed), {})
                for rid, r in idmap.items():
                    n_results += 1
                    codes = codes_of(r)
                    allcodes += len(codes)
                    ooc += sum(1 for x in codes if x not in c.CATALOG_CODES)  # judge_grid.py:45
                    has_code = any(ind.get("codes") for ind in r.get("indications", []))
                    if r.get("indications") and has_code:
                        n_covered += 1
                    if not (r.get("usage_summary") or "").strip():
                        usage_missing += 1
                    for ind in r.get("indications", []):
                        n_ind += 1
                        if not (ind.get("confidence_rationale") or "").strip():
                            rat_missing += 1
                        for cc in ind.get("codes", []):
                            cf = cc.get("confidence")
                            if not (isinstance(cf, (int, float)) and 0.0 <= cf <= 1.0):
                                conf_bad += 1
        halluc[key] = dict(returned_codes=allcodes, out_of_catalog=ooc,
                           hallucination_rate=round(ooc / max(1, allcodes), 4))
        coverage[key] = dict(results=n_results, covered=n_covered,
                             coverage=round(n_covered / max(1, n_results), 4))
        schema[key] = dict(results=n_results, indications=n_ind,
                           confidence_out_of_range=conf_bad,
                           indications_missing_rationale=rat_missing,
                           results_missing_usage_summary=usage_missing,
                           schema_valid=(conf_bad == 0 and rat_missing == 0 and usage_missing == 0))

    # ---- MEASURE 5 legal-correctness (bed2): generic subset-of-brand ----
    legal = {}
    for key in model_keys:
        up = union_pass.get((key, "bed2"), {})
        # molecule_id -> brand code pool, list of (generic id, codeset)
        brand_pool = defaultdict(set)
        generics = defaultdict(list)
        for rid, cset in up.items():
            rec = bed_rec["bed2"].get(rid)
            if not rec:
                continue
            mol = rec.get("molecule_id")
            kind = rec.get("kind")
            if kind == "brand":
                brand_pool[mol] |= cset
            elif kind == "generic":
                generics[mol].append((rid, cset))
        identical = subset = divergent = total = 0
        skipped_mol = 0
        mols_with_generics = set(generics)
        for mol in mols_with_generics:
            if not brand_pool.get(mol):
                skipped_mol += 1
                continue
            ref = brand_pool[mol]
            for rid, cset in generics[mol]:
                total += 1
                if cset == ref:
                    identical += 1
                elif cset <= ref:
                    subset += 1
                else:
                    divergent += 1
        legal[key] = dict(generics_classified=total, identical=identical, subset=subset,
                          superset_or_divergent=divergent,
                          pass_rate=round((identical + subset) / max(1, total), 4),
                          molecules_skipped_no_brand_ref=skipped_mol)

    # ---- MEASURE 6a pass1 vs pass2 stability (all beds) ----
    # ---- MEASURE 6b bed2 per-SPL union per molecule vs bed3 union codes ----
    consistency = {}
    for key in model_keys:
        jaccs, exacts = [], []
        for bed in BEDS:
            pp = by_pass.get((key, bed), {})
            m1, m2 = pp.get(1, {}), pp.get(2, {})
            for rid in set(m1) & set(m2):
                a, b = m1[rid], m2[rid]
                if not a and not b:
                    jaccs.append(1.0); exacts.append(1.0); continue
                inter = len(a & b); uni = len(a | b)
                jaccs.append(inter / max(1, uni))
                exacts.append(1.0 if a == b else 0.0)
        # 6b reconstruction: bed2 per-molecule union vs bed3 union
        bed2u = defaultdict(set)
        for rid, cset in union_pass.get((key, "bed2"), {}).items():
            rec = bed_rec["bed2"].get(rid)
            if rec:
                bed2u[rec.get("molecule_id")] |= cset
        bed3u = defaultdict(set)
        for rid, cset in union_pass.get((key, "bed3"), {}).items():
            rec = bed_rec["bed3"].get(rid)
            if rec:
                bed3u[rec.get("molecule_id")] |= cset
        recon_jacc, recon_recall = [], []
        for mol in set(bed2u) & set(bed3u):
            a, b = bed2u[mol], bed3u[mol]  # a = reconstructed from per-SPL, b = union output
            uni = len(a | b)
            recon_jacc.append(len(a & b) / max(1, uni))
            if b:
                recon_recall.append(len(a & b) / len(b))
        consistency[key] = dict(
            pass_pairs=len(jaccs),
            pass_jaccard=round(sum(jaccs) / len(jaccs), 4) if jaccs else None,
            pass_exact_match=round(sum(exacts) / len(exacts), 4) if exacts else None,
            recon_molecules=len(recon_jacc),
            bed2_vs_bed3_jaccard=round(sum(recon_jacc) / len(recon_jacc), 4) if recon_jacc else None,
            bed3_recall_from_bed2=round(sum(recon_recall) / len(recon_recall), 4) if recon_recall else None,
        )

    # ---- MEASURE 7 cross-model agreement (judge_grid.py:56-68), per SPL=(bed,id), union over passes ----
    # cs[key][(bed,id)] = codeset
    cs = {key: {} for key in model_keys}
    for (key, bed), idmap in union_pass.items():
        for rid, cset in idmap.items():
            cs[key][(bed, rid)] = cset
    all_spls = set().union(*[set(cs[k]) for k in model_keys]) if model_keys else set()
    agree = {k: [] for k in model_keys}
    for spl in all_spls:
        sets = {k: cs[k][spl] for k in model_keys if spl in cs[k]}
        if len(sets) < 2:
            continue
        cnt = Counter(code for st in sets.values() for code in st)
        consensus = {code for code, n in cnt.items() if n >= 2}  # judge_grid.py:62
        if not consensus:
            continue
        for k, st in sets.items():
            agree[k].append(len(st & consensus) / len(consensus))  # judge_grid.py:65
    xmodel = {k: dict(spls_compared=len(agree[k]),
                      agreement=round(sum(agree[k]) / len(agree[k]), 4) if agree[k] else None)
              for k in model_keys}

    # ---- MEASURE 8 cost + MEASURE 9 reliability (tokens over every file of the model) ----
    price = {m["key"]: m for m in c.MODELS}
    cost = {}
    reliability = {}
    for key in model_keys:
        sin = scache = sout = 0
        retries_total = 0
        batches_with_retry = 0
        batches_valid = 0
        for d in all_files:
            if d.get("key") != key:
                continue
            u = d.get("usage") or {}
            sin += u.get("input_tokens") or 0
            scache += u.get("cached_input_tokens") or 0
            sout += u.get("output_tokens") or 0
            tr = u.get("transient_retries") or 0
            if d.get("output") is not None:
                batches_valid += 1
                retries_total += tr
                if tr > 0:
                    batches_with_retry += 1
        n_spl = sum(len(merged.get((key, p, bed), {})) for p in (1, 2) for bed in BEDS)  # returned results
        spec = price[key]
        ri, rc, ro = spec["price_in"], spec.get("price_cached") or 0.0, spec["price_out"]
        # judge_grid.py:47 cost formula - uncached input at ri, cached at rc, output at ro
        total_cost = ((sin - scache) * ri + scache * rc + sout * ro) / 1e6
        lc = LONGCTX.get(key)
        lc_cost = None
        if lc:
            lri, lrc, lro = lc
            lc_cost = ((sin - scache) * lri + scache * lrc + sout * lro) / 1e6
        cost[key] = dict(
            input_tokens=sin, cached_input_tokens=scache, output_tokens=sout,
            returned_results=n_spl,
            prices_per_1m=dict(input=ri, cached=rc, output=ro),
            total_cost_usd=round(total_cost, 4),
            cost_per_spl=round(total_cost / max(1, n_spl), 6),
            cost_per_1000_spl=round(1000 * total_cost / max(1, n_spl), 4),
            longctx_total_cost_usd=round(lc_cost, 4) if lc_cost is not None else None,
            longctx_cost_per_1000_spl=round(1000 * lc_cost / max(1, n_spl), 4) if lc_cost is not None else None,
        )
        reliability[key] = dict(valid_batches=batches_valid,
                                transient_retries_total=retries_total,
                                batches_needing_retry=batches_with_retry)

    # ---- assemble ----
    out = {
        "generated_over": "results_v7",
        "partial": bool(partial_note),
        "partial_note": partial_note,
        "attempted_cells": len(attempted),
        "full_grid_cells": full_grid,
        "bed_sizes": bed_sizes,
        "models": model_keys,
        "cost_projection_note": (
            "cost_per_1000_spl is the measured per-1000 rate; projected-full-build = "
            "cost_per_1000_spl x (production SPL count / 1000). The production SPL count is "
            "NOT present in these result files, so full-build $ is not computed here. "
            "Long-context caveat: the ~440K-token prompt exceeds every provider's 200K/272K "
            "threshold; openai long-context rate confirmed, Gemini >200K tier UNCONFIRMED "
            "(longctx_* fields show the alternate costing). Primary cost uses c.MODELS prices."
        ),
        "per_model": {
            key: {
                "hallucination": halluc[key],
                "coverage": coverage[key],
                "drops": drop_stats[key],
                "schema": schema[key],
                "legal_correctness_bed2": legal[key],
                "consistency": consistency[key],
                "cross_model_agreement": xmodel[key],
                "cost": cost[key],
                "reliability": reliability[key],
            } for key in model_keys
        },
        "unmappable_files": unmappable,
    }
    (R / "scores_v7.json").write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")

    # ---- compact summary table ----
    rows = []
    for key in model_keys:
        rows.append({
            "model": key,
            "halluc": halluc[key]["hallucination_rate"],
            "cover": coverage[key]["coverage"],
            "drop_lost": drop_stats[key]["finally_lost"],
            "drop_recov": drop_stats[key]["recovered"],
            "tok_lim_lost": drop_stats[key]["token_limit_lost"],
            "schema_ok": schema[key]["schema_valid"],
            "legal_pass": legal[key]["pass_rate"],
            "p1p2_jacc": consistency[key]["pass_jaccard"],
            "b2_b3_recall": consistency[key]["bed3_recall_from_bed2"],
            "xagree": xmodel[key]["agreement"],
            "retries": reliability[key]["transient_retries_total"],
            "$/1k_spl": cost[key]["cost_per_1000_spl"],
        })
    cols = ["model", "halluc", "cover", "drop_lost", "drop_recov", "tok_lim_lost", "schema_ok",
            "legal_pass", "p1p2_jacc", "b2_b3_recall", "xagree", "retries", "$/1k_spl"]
    w = {col: max(len(col), *(len(str(r[col])) for r in rows)) for col in cols}
    print(" | ".join(col.ljust(w[col]) for col in cols))
    print("-+-".join("-" * w[col] for col in cols))
    for r in rows:
        print(" | ".join(str(r[col]).ljust(w[col]) for col in cols))
    if partial_note:
        print("\nPARTIAL: " + " ".join(partial_note))
    print(f"\nwrote {R / 'scores_v7.json'}  |  attempted {len(attempted)}/{full_grid} grid cells")
    print("columns: halluc=out-of-catalog share (bed1+bed2); cover=>=1 ind & >=1 code; "
          "drop_lost/recov=ids finally lost / recovered by retest; tok_lim_lost=lost to the "
          "32000-token-limit null batches; legal_pass=bed2 generic identical|subset of brand; "
          "p1p2_jacc=pass stability; b2_b3_recall=per-SPL union reconstructs bed3 union; "
          "xagree=overlap with >=2-model consensus; $/1k_spl uses c.MODELS prices.")


if __name__ == "__main__":
    main()
