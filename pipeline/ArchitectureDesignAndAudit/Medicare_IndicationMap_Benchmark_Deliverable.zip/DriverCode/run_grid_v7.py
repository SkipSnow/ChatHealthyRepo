"""v7 FULL run (test plan v7 section 7): the full bed set - Test bed 1 (benchmark_sample.jsonl),
Test bed 2 (benchmark_sample_v2.jsonl), Test bed 3 (benchmark_sample_v3_union.jsonl) - for each
model, in 2 independent passes (consistency = stability between passes). Batch 50; if a model
drops any id in a batch, REFIRE only the dropped ids (bounded retest rounds). Persist-first to
results_v7/, atomic, resumable (a persisted (pass,bed,model,batch,round) with output is reused,
never re-fired). The caller does NOTHING but fire and persist; scoring is separate.

NOTHING FIRES ON IMPORT. A call happens only when this file is executed as __main__, which the
operator has authorized end-to-end for this run (LLM calls cost money)."""
import os, sys, json, pathlib, datetime, threading, concurrent.futures

root = pathlib.Path(r"c:\CHATHealthyLLC")
sys.path.insert(0, str(root)); sys.path.insert(0, str(root / "ChatHealthyLib" / "src"))
env = root / ".env"
if env.is_file():
    for line in env.read_text(encoding="utf-8", errors="replace").splitlines():
        if "=" in line and not line.strip().startswith("#"):
            k, v = line.split("=", 1); os.environ.setdefault(k.strip(), v.strip())
HARNESS = root / "_oneshots" / "medicare_benchmark" / "harness"
sys.path.insert(0, str(HARNESS))
import crosswalk as c

RESULTS = HARNESS / "results_v7"
BATCH = 50
MAX_RETEST = 3
PASSES = [1, 2]
MAX_WORKERS = 6   # bounded concurrency; crosswalk.run_batch retries/backs off on 429
BEDS = [
    ("bed1", "benchmark_sample.jsonl"),
    ("bed2", "benchmark_sample_v2.jsonl"),
    ("bed3", "benchmark_sample_v3_union.jsonl"),
]

# Gate result (proof, v7 schema): grok-4.3 FAILED (UnexpectedModelBehavior: exceeded maximum
# output retries) - it cannot reliably produce the v7 output_type at batch 50. It is excluded
# from this run; the other three proved 50/50 with 0 out-of-catalog. Exclusion is logged below,
# never silent.
EXCLUDE = {"xai:grok-4.3"}
MODELS = [m for m in c.MODELS if m["key"] not in EXCLUDE]


def _load(bedfile):
    recs = [json.loads(l) for l in (HARNESS / bedfile).read_text(encoding="utf-8").splitlines()
            if l.strip()]
    return [c.DrugInput(id=str(i),
                        molecule=str(r.get("molecule") or r.get("molecule_id") or ""),
                        indication_text=r["indication_text"])
            for i, r in enumerate(recs)]


def _persist(path, record):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _returned_ids(path):
    try:
        d = json.loads(path.read_text(encoding="utf-8"))
        out = d.get("output")
        return {r["id"] for r in (out["results"] if out else [])}
    except Exception:
        return set()


_print_lock = threading.Lock()


def _log(msg):
    with _print_lock:
        print(msg, flush=True)


def _do_batch(p, bedname, by_id, spec, bi, batch):
    """Fire one batch (with retest-on-drop) and persist. Resume-aware: a persisted
    (pass,bed,model,batch,round) that already returned ids is reused, not re-fired.
    Each batch writes its own distinct file, so this is safe to run concurrently."""
    key = spec["key"].replace(":", "_")
    remaining = {d.id for d in batch}
    for rnd in range(0, MAX_RETEST + 1):
        if not remaining:
            break
        path = RESULTS / f"run__p{p}__{bedname}__{key}__b{bi}__r{rnd}.json"
        if path.exists() and _returned_ids(path):
            remaining -= _returned_ids(path)
            continue
        fire = batch if rnd == 0 else [by_id[i] for i in sorted(remaining, key=int)]
        _log(f"firing p{p} {bedname} {spec['key']} b{bi} r{rnd} ({len(fire)} inferences) ...")
        out, usage, meta = c.run_batch(spec, fire)
        record = {
            "key": spec["key"], "model_id": spec["id"], "provider": spec["provider"],
            "pass": p, "bed": bedname, "batch_index": bi, "round": rnd,
            "input_ids": [d.id for d in fire],
            "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "output": out.model_dump() if out is not None else None,
            "usage": usage, "meta": meta,
        }
        _persist(path, record)
        got = {r.id for r in out.results} if out is not None else set()
        remaining -= got
        _log(f"  -> {path.name} returned={len(got)}/{len(fire)} missing={len(remaining)} "
             f"error={meta.get('error')}")
    return (p, bedname, spec["key"], bi, len(remaining))


def run():
    RESULTS.mkdir(exist_ok=True)
    items, bed_sizes = [], []
    for p in PASSES:
        for bedname, bedfile in BEDS:
            drugs = _load(bedfile)
            by_id = {d.id: d for d in drugs}
            batches = [drugs[i:i + BATCH] for i in range(0, len(drugs), BATCH)]
            if p == PASSES[0]:
                bed_sizes.append((bedname, len(drugs)))
            for spec in MODELS:
                for bi, batch in enumerate(batches):
                    items.append((p, bedname, by_id, spec, bi, batch))
    _log(f"v7 grid (concurrent, max_workers={MAX_WORKERS}): {[s['key'] for s in MODELS]} | "
         f"passes={PASSES} | beds={bed_sizes} | {len(items)} base batches")
    _log(f"EXCLUDED (failed v7 proof gate): {sorted(EXCLUDE)}")
    dropped = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        futs = [ex.submit(_do_batch, *it) for it in items]
        for fut in concurrent.futures.as_completed(futs):
            try:
                p, bedname, mkey, bi, miss = fut.result()
                if miss:
                    dropped.append((p, bedname, mkey, bi, miss))
                    _log(f"  !! p{p} {bedname} {mkey} b{bi}: {miss} id(s) DROPPED after "
                         f"{MAX_RETEST} retests")
            except Exception as e:  # noqa: BLE001
                _log(f"WORKER ERROR: {repr(e)}")
    _log(f"DONE v7 grid. dropped_batches={len(dropped)}")


if __name__ == "__main__":
    run()
