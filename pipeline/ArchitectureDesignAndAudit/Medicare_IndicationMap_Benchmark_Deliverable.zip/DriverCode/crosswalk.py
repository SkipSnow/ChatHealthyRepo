"""Crosswalk tool: drug indication text -> indications, each with its level-3/4 ICD-10 codes.
One pydantic-ai Agent, model swapped per run. BUILD ONLY - no model call happens on import or
construction; a call fires only when run_batch() is invoked (operator-gated, costs money)."""
import os, json, pathlib, time
from pydantic import BaseModel, Field
from openpyxl import load_workbook

BASE = pathlib.Path(r"c:\CHATHealthyLLC\_oneshots\medicare_benchmark")

# ---------------- schemas (Appendix B) ----------------
class DrugInput(BaseModel):
    id: str
    molecule: str = ""
    rxcui: list[str] = Field(default_factory=list)  # SPL openfda.rxcui; carried, not used by the crosswalk
    indication_text: str

class CrosswalkBatchInput(BaseModel):
    drugs: list[DrugInput]

class CodeConfidence(BaseModel):
    icd10_code: str
    confidence: float = Field(ge=0.0, le=1.0)

class Indication(BaseModel):
    indication: str
    confidence_rationale: str
    codes: list[CodeConfidence]

class DrugResult(BaseModel):
    id: str
    usage_summary: str
    indications: list[Indication]

class CrosswalkBatchOutput(BaseModel):
    results: list[DrugResult]

# ---------------- catalog (level 3 + 4) ----------------
def load_catalog():
    wb = load_workbook(BASE / "icd10_categories_top3levels.xlsx", read_only=True)
    ws = wb.active
    it = ws.iter_rows(values_only=True)
    hdr = next(it)
    ix = {h: i for i, h in enumerate(hdr)}
    lines, codes = [], set()
    for r in it:
        lvl = r[ix["level"]]
        if lvl in (3, 4):
            code = str(r[ix["icd10_code"]]).strip()
            desc = str(r[ix["short_description"]] or "").strip()
            lines.append(f"{code}\t{desc}")
            codes.add(code)
    return "\n".join(lines), codes

CATALOG, CATALOG_CODES = load_catalog()

SYSTEM_PROMPT = (
    'You are an expert clinical coder. You are given a batch of records in the input field named '
    '"drugs" (named so for model familiarity). Each element is ONE record: one SPL\'s FDA '
    '"Indications and Usage" text. "drug" here means one record -- one label -- not a marketed '
    'product. For each record, read its Indications and Usage text and produce the list of '
    'distinct indications it is indicated to treat. '
    'For each indication, list ALL of its ICD-10-CM codes at the 3-character and 4-character '
    'levels, chosen ONLY from the catalog below -- never emit a code that is not in the '
    'catalog. Give each code a confidence from 0 to 1, and give each indication a short '
    'confidence_rationale: one plain sentence explaining that confidence. A best guess is '
    'acceptable. Be honest and conservative with confidence: reserve high confidence for '
    'genuinely clear cases, and do not inflate it -- not braggadocious. '
    'Also return, per record, a usage_summary: a concise summary of the clinical usage context in '
    'the Indications and Usage text that is distinct from the indication itself (target '
    'populations, limitations of use), with document noise (figure captions, trial statistics) '
    'omitted. Return one result per input record, keyed by its id.\n\n'
    'ICD-10-CM catalog - each line is <icd10_code><TAB><short_description>; icd10_code has no '
    'decimal point (e.g. F32 or F329). One per line:\n' + CATALOG
)

def user_message(drugs: list[DrugInput]) -> str:
    arr = [{"id": d.id, "molecule": d.molecule, "indication_text": d.indication_text} for d in drugs]
    return "Drugs:\n" + json.dumps(arr, ensure_ascii=False, indent=1)

# ---------------- model registry ----------------
# IDs current as of 2026-10-10; pinned/validated against each provider's live list at build.
# effort = each provider's max; prices are a DATED table, filled at run time (None = fill before costing).
# Under-$1.00-per-150-job models only (operator 2026-10-10: test sub-$1 first).
# Prices $/1M, dated 2026-10-10 from provider pricing pages; pinned at run time.
MODELS = [
    {"key": "openai:5.6-luna",  "provider": "openai", "id": "gpt-5.6-luna",          "price_in": 0.20, "price_cached": 0.02,  "price_out": 1.20},
    {"key": "google:3.5-flite", "provider": "google", "id": "gemini-3.5-flash-lite", "price_in": 0.30, "price_cached": 0.03,  "price_out": 2.50},
    {"key": "google:3.8-flash", "provider": "google", "id": "gemini-3.8-flash",      "price_in": 0.75, "price_cached": 0.075, "price_out": 3.75},
    # Grok restored for benchmark #2: its batch drops in #1 are now covered by the retest-on-drop
    # protocol. price_cached unconfirmed; the dated table is pinned at run time, not trusted here.
    {"key": "xai:grok-4.3",     "provider": "xai",    "id": "grok-4.3",              "price_in": 1.25, "price_cached": None,   "price_out": 2.50},
]

def _env(*names):
    for n in names:
        v = os.environ.get(n)
        if v:
            return v
    return None

def build_agent(spec: dict):
    """Construct the pydantic-ai Agent for one model at max effort. No network call here."""
    from pydantic_ai import Agent
    prov = spec["provider"]
    if prov == "anthropic":
        from pydantic_ai.models.anthropic import AnthropicModel, AnthropicModelSettings
        from pydantic_ai.providers.anthropic import AnthropicProvider
        model = AnthropicModel(spec["id"], provider=AnthropicProvider(api_key=_env("ANTHROPIC_API_KEY")))
        settings = AnthropicModelSettings(
            anthropic_thinking={"type": "adaptive"},   # Claude 5 family: max reasoning
            anthropic_cache_instructions=True,          # cache the system prompt (the catalog)
            max_tokens=32000,
        )
    elif prov == "openai":
        # Responses API: reasoning_effort + structured output are supported here
        # (Chat Completions rejects the combination since GPT-5.4).
        from pydantic_ai.models.openai import OpenAIResponsesModel, OpenAIResponsesModelSettings
        from pydantic_ai.providers.openai import OpenAIProvider
        model = OpenAIResponsesModel(spec["id"], provider=OpenAIProvider(api_key=_env("OPENAI_API_KEY")))
        settings = OpenAIResponsesModelSettings(openai_reasoning_effort="xhigh", max_tokens=32000)
    elif prov == "google":
        from pydantic_ai.models.google import GoogleModel, GoogleModelSettings
        from pydantic_ai.providers.google import GoogleProvider
        model = GoogleModel(spec["id"], provider=GoogleProvider(api_key=_env("GEMINI_API_KEY", "GOOGLE_API_KEY")))
        settings = GoogleModelSettings(google_thinking_config={"thinking_level": "high"}, max_tokens=32000)
    elif prov == "xai":
        from pydantic_ai.models.xai import XaiModel, XaiModelSettings
        from pydantic_ai.providers.xai import XaiProvider
        model = XaiModel(spec["id"], provider=XaiProvider(api_key=_env("GrokXAPIKey", "XAI_API_KEY")))
        settings = XaiModelSettings(xai_reasoning_effort="high", max_tokens=32000)  # 'high' is Grok's max
    else:
        raise ValueError(f"unknown provider {prov}")
    return Agent(model, output_type=CrosswalkBatchOutput, system_prompt=SYSTEM_PROMPT,
                 model_settings=settings, retries=2)   # retries = output-validation re-asks

def _extract_usage(res, attempt):
    """Best-effort; a usage-extraction slip must NEVER discard a successful (paid) result."""
    out = {"transient_retries": attempt}
    try:
        u = res.usage                      # property in pydantic-ai 2.35 (not callable)
        out["input_tokens"] = getattr(u, "input_tokens", None)
        out["output_tokens"] = getattr(u, "output_tokens", None)
        out["cached_input_tokens"] = getattr(u, "cache_read_tokens", None)
        out["total_tokens"] = getattr(u, "total_tokens", None)
        det = getattr(u, "details", None) or {}
        out["reasoning_tokens"] = det.get("reasoning_tokens") or det.get("thoughts_tokens")
    except Exception as e:                 # noqa: BLE001
        out["usage_error"] = repr(e)[:200]
    return out

def _safe_raw(res):
    """Best-effort serialization of the raw model messages; never raises."""
    try:
        from pydantic_core import to_jsonable_python
        return to_jsonable_python(res.all_messages())
    except Exception:
        try:
            return [str(m) for m in res.all_messages()]
        except Exception:
            return None

def run_batch(spec: dict, drugs: list[DrugInput], max_transient_retries: int = 5):
    """FIRES A MODEL CALL (costs money). Returns (output, usage_dict, meta). Operator-gated."""
    agent = build_agent(spec)
    attempt, backoff, last = 0, 2.0, None
    while attempt <= max_transient_retries:
        try:
            res = agent.run_sync(user_message(drugs))
        except Exception as ex:   # noqa: BLE001  (record, never fabricate)
            last = ex
            msg = str(ex).lower()
            transient = any(s in msg for s in ("429", "rate", "timeout", "timed out", "500", "502",
                                               "503", "529", "overloaded", "connection"))
            if not transient or attempt == max_transient_retries:
                return None, {"transient_retries": attempt}, {"error": repr(ex)[:500]}
            time.sleep(backoff); backoff *= 2; attempt += 1
            continue
        # call succeeded -> extract usage + raw defensively and return the result no matter what
        return res.output, _extract_usage(res, attempt), {"error": None, "raw_messages": _safe_raw(res)}
    return None, {"transient_retries": attempt}, {"error": repr(last)[:500]}
