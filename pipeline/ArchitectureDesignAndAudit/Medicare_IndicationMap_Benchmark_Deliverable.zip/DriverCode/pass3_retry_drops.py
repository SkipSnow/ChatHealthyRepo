"""Retest-on-drop (V11 section 5) for the 750 run: re-enrich the no-code records
(mostly model drops) and merge any that now code. Fires luna. One-off."""
import os
import sys
import json
import pathlib

ROOT = pathlib.Path(r"c:\CHATHealthyLLC")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "ChatHealthyLib" / "src"))
sys.path.insert(0, str(ROOT / "pipeline" / "MedicareProviderEvaluationDataPipeline"))
for line in (ROOT / ".env").read_text(encoding="utf-8", errors="replace").splitlines():
    if "=" in line and not line.strip().startswith("#"):
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())

SCR = ROOT / "_oneshots" / "medicare_benchmark" / "harness" / "pass3_local_scratch"
CATALOG = ROOT / "_oneshots" / "medicare_benchmark" / "icd10_categories_top3levels.xlsx"

recs = [json.loads(l) for l in (SCR / "map_records.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
by_setid = {r.get("set_id"): r for r in recs}
nocode_ids = {r.get("set_id") for r in recs if not any(ind.get("codes") for ind in r.get("indications", []))}
print(f"retrying {len(nocode_ids)} no-code records", flush=True)

import urllib.request  # noqa: E402
import urllib.parse  # noqa: E402
import time  # noqa: E402

retry_records = []
for sid in sorted(nocode_ids):
    url = "https://api.fda.gov/drug/label.json?search=" + urllib.parse.quote(f'set_id:"{sid}"') + "&limit=1"
    try:
        res = json.load(urllib.request.urlopen(url, timeout=30)).get("results", [])
    except Exception as e:  # noqa: BLE001
        print(f"  refetch {sid} failed: {repr(e)[:80]}", flush=True)
        continue
    if not res:
        continue
    d = res[0]
    of = d.get("openfda") or {}
    subs = of.get("substance_name") or of.get("generic_name") or []
    molecule = " + ".join(subs) if subs else ((of.get("brand_name") or ["UNKNOWN"])[0] or "UNKNOWN")
    iau = d.get("indications_and_usage") or []
    retry_records.append({"set_id": d.get("set_id"), "id": d.get("id"), "molecule": molecule,
                          "indication_text": (" ".join(iau) if isinstance(iau, list) else str(iau)),
                          "openfda": of})
    time.sleep(0.3)
print(f"re-enriching {len(retry_records)} re-fetched labels", flush=True)

import fda_drug_enrichment_tool as T  # noqa: E402
tool = T.FDADrugEnrichmentTool(model="gpt-5.6-luna", catalog=str(CATALOG))
retried = tool.enrich(retry_records)

recovered = 0
for r in retried:
    rd = r.model_dump()
    if any(ind.get("codes") for ind in rd.get("indications", [])):
        recovered += 1
    by_setid[rd.get("set_id")] = rd  # merge (replace) regardless

merged = list(by_setid.values())
(SCR / "map_records.jsonl").write_text("\n".join(json.dumps(r) for r in merged), encoding="utf-8")

n = len(merged)
withcodes = sum(1 for r in merged if any(ind.get("codes") for ind in r.get("indications", [])))
print(f"recovered (now have >=1 code): {recovered}/{len(retry_records)}", flush=True)
print(f"TRUE coverage after retry: {withcodes}/{n} ({100*withcodes/n:.0f}%)", flush=True)
print(f"last crosswalk usage: {tool.last_crosswalk_usage()}", flush=True)
