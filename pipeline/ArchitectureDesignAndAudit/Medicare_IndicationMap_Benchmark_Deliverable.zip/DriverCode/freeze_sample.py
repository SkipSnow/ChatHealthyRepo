"""Freeze the 150-molecule benchmark sample from the test bed. No network, no model calls."""
import json, hashlib, pathlib

BASE = pathlib.Path(r"c:\CHATHealthyLLC\_oneshots\medicare_benchmark")
SRC = BASE / "testbed" / "molecules.jsonl"
OUT = BASE / "harness" / "benchmark_sample.jsonl"
MANIFEST = BASE / "harness" / "benchmark_sample.manifest.json"
N = 150

mols = []
with open(SRC, encoding="utf-8") as fh:
    for line in fh:
        line = line.strip()
        if line:
            mols.append(json.loads(line))

# only molecules that actually carry indication prose (the inference needs it)
mols = [m for m in mols if (m.get("indications_text") or "").strip()]
mols.sort(key=lambda m: m.get("molecule_key") or m.get("display_name") or "")

both = [m for m in mols if m.get("has_brand") and m.get("has_generic")]
rest = [m for m in mols if not (m.get("has_brand") and m.get("has_generic"))]

selected = list(both[:N])                      # all brand+generic pairs first (legal-correctness)
if len(selected) < N:
    need = N - len(selected)
    # deterministic even spread across the remaining molecules
    if rest:
        stride = max(1, len(rest) // need)
        picked = rest[::stride][:need]
        if len(picked) < need:                 # top up if stride left us short
            seen = {id(x) for x in picked}
            picked += [x for x in rest if id(x) not in seen][: need - len(picked)]
        selected += picked
selected = selected[:N]

def slim(m):
    return {
        "id": m["molecule_key"] if isinstance(m.get("molecule_key"), str)
              else " + ".join(m.get("molecule_key") or []) or m.get("display_name", ""),
        "molecule": m.get("display_name", ""),
        "indication_text": m.get("indications_text", ""),
        "has_brand": bool(m.get("has_brand")),
        "has_generic": bool(m.get("has_generic")),
    }

records = [slim(m) for m in selected]
payload = "\n".join(json.dumps(r, ensure_ascii=False) for r in records) + "\n"
OUT.write_text(payload, encoding="utf-8")

h = hashlib.sha256(payload.encode("utf-8")).hexdigest()
n_pairs = sum(1 for r in records if r["has_brand"] and r["has_generic"])
MANIFEST.write_text(json.dumps({
    "source": str(SRC), "n_selected": len(records), "n_brand_generic_pairs": n_pairs,
    "selection": "all brand+generic pairs first, then a deterministic even-stride spread over the rest, sorted by id",
    "sha256": h,
}, indent=2), encoding="utf-8")

print(f"wrote {OUT}")
print(f"selected={len(records)}  brand+generic_pairs={n_pairs}  sha256={h[:16]}")
