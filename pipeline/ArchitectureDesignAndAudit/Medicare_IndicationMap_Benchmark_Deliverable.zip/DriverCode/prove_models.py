"""Prove every target model: fire ONE call (same first-50 molecules) per model, persist-first.
Resumable: a model already proven (its proof file has output) is skipped, never re-fired."""
import os, sys, json, pathlib, datetime
root = pathlib.Path(r"c:\CHATHealthyLLC")
sys.path.insert(0, str(root)); sys.path.insert(0, str(root / "ChatHealthyLib" / "src"))
env = root / ".env"
if env.is_file():
    for line in env.read_text(encoding="utf-8", errors="replace").splitlines():
        if "=" in line and not line.strip().startswith("#"):
            k, v = line.split("=", 1); os.environ.setdefault(k.strip(), v.strip())
HARNESS = root / "_oneshots" / "medicare_benchmark" / "harness"
sys.path.insert(0, str(HARNESS))
import crosswalk as c

RESULTS = HARNESS / "results"; RESULTS.mkdir(exist_ok=True)
sample = [json.loads(l) for l in (HARNESS / "benchmark_sample.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
drugs = [c.DrugInput(id=r["id"], molecule=r["molecule"], indication_text=r["indication_text"]) for r in sample[:50]]

for spec in c.MODELS:
    path = RESULTS / f"proof_v7__{spec['key'].replace(':', '_')}.json"
    if path.exists():
        try:
            if json.loads(path.read_text(encoding="utf-8")).get("output") is not None:
                print(f"SKIP (already proven): {spec['key']}", flush=True); continue
        except Exception:
            pass
    print(f"firing: {spec['key']} ({spec['id']}) x {len(drugs)} ...", flush=True)
    out, usage, meta = c.run_batch(spec, drugs)
    record = {
        "key": spec["key"], "model_id": spec["id"], "provider": spec["provider"],
        "input_ids": [d.id for d in drugs],
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "output": out.model_dump() if out is not None else None, "usage": usage, "meta": meta,
    }
    tmp = path.with_suffix(".tmp"); tmp.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)
    # read-back summary (from the persisted file, so the result is already safe)
    ooc = 0; nres = 0
    if out is not None:
        nres = len(out.results)
        codes = [cc.icd10_code for r in out.results for ind in r.indications for cc in ind.codes]
        ooc = len({x for x in codes if x not in c.CATALOG_CODES})
    print(f"  -> output_present={out is not None} results={nres}/{len(drugs)} "
          f"out_of_catalog={ooc} in={usage.get('input_tokens')} out={usage.get('output_tokens')} "
          f"reason={usage.get('reasoning_tokens')} error={meta.get('error')}", flush=True)

print("DONE proving all models.", flush=True)
