"""Deterministic RXCUI resolution funnel across the ENTIRE drug set - no LLM (tier 3 is NOT
here; that is the least-important residue). This is the visibility that was missing: for each
drug, which deterministic tier resolved it, and - for the fall-through - the exact drugs no
deterministic tier could resolve, so we can see whether the misses cluster on the drugs we care
least about (combinations / off-label / uncategorizable).

  tier 1 - formulary-RXCUI (exact match against the CMS Part D Formulary Reference File, FDB
           name -> RXCUI). NOT YET WIRED: it needs that formulary file (and, for the production
           drug universe, the CMS Part D data from the paused cluster). This is FLAGGED here,
           not silently skipped. Resolution currently starts at tier 2.
  tier 2 - RxNorm exact (findRxcuiByString search=0) then normalized (search=1) via RxNav.
           Deterministic, free. search=9 (approximate) is forbidden as a key.
"""
import json, pathlib, time, urllib.request, urllib.parse, collections

ROOT = pathlib.Path(r"c:\CHATHealthyLLC\_oneshots\medicare_benchmark")
MOL = ROOT / "testbed" / "molecules.jsonl"
OUT = ROOT / "harness" / "resolve_funnel_results.jsonl"
RXNAV = "https://rxnav.nlm.nih.gov/REST/rxcui.json?name={}&search={}"
_cache = {}


def rxnorm(name, search):
    key = (name.lower(), search)
    if key in _cache:
        return _cache[key]
    u = RXNAV.format(urllib.parse.quote(name), search)
    ids = []
    for attempt in range(4):
        try:
            r = json.load(urllib.request.urlopen(u, timeout=25))
            ids = (r.get("idGroup") or {}).get("rxnormId") or []
            break
        except Exception:
            time.sleep(1.5 * (attempt + 1))
    _cache[key] = ids
    return ids


def tier2(name):
    ids = rxnorm(name, 0)
    if ids:
        return "tier2_exact", ids
    ids = rxnorm(name, 1)
    if ids:
        return "tier2_normalized", ids
    return None, []


def main():
    mols = [json.loads(l) for l in MOL.read_text(encoding="utf-8").splitlines() if l.strip()]
    counts = collections.Counter()
    fallthrough = []
    print(f"resolve_funnel: {len(mols)} molecules | tier1=NOT-WIRED(flagged) tier2=RxNorm", flush=True)
    with OUT.open("w", encoding="utf-8") as f:
        for i, m in enumerate(mols):
            name = m.get("molecule_id") or ""
            truth = m.get("rxcuis") or []
            by, ids = tier2(name)
            combo = "+" in name
            matched = bool(set(str(x) for x in ids) & set(str(x) for x in truth)) if ids else False
            rec = {"i": i, "name": name, "resolved_by": by or "unresolved_by_deterministic",
                   "rxcui": ids, "truth_rxcui": truth, "combination": combo,
                   "matches_openfda_rxcui": matched}
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            counts[by or "unresolved_by_deterministic"] += 1
            if by is None:
                fallthrough.append((name, combo))
            if i % 250 == 0:
                print(f"  {i}/{len(mols)} {dict(counts)}", flush=True)
            time.sleep(0.06)
    combos = sum(1 for _, c in fallthrough if c)
    print(f"DONE {dict(counts)}", flush=True)
    print(f"fall-through (no deterministic tier) = {len(fallthrough)}; "
          f"combinations among them = {combos} "
          f"({100*combos/max(1,len(fallthrough)):.0f}% of the misses)", flush=True)


if __name__ == "__main__":
    main()
