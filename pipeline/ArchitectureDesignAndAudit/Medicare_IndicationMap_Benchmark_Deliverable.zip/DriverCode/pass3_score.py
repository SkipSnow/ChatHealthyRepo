# Copyright (c) 2026 ChatHealthy.ai LLC. All rights reserved.
# Licensed under the FindCare Evaluation License (FEL-1.0).

"""Pass-3 scorer (Test Plan V11 section 8 + section 12).

READ-ONLY over the persist-first scratch the runner wrote, plus bed2 and the
ICD-10-CM catalog. NO model call, NO RxNav call, NO MongoDB connection -- every
Pass-3 measure is computed from the raw PROMPT 1 and PROMPT 2 outputs on scratch.
A separate program from the runner (section 5): no paid result is discardable by
a scoring bug, and scoring never re-fires.

Emits:
  * pass3_scores.json  -- every section-8 measure plus the section-12 synthesis.
  * pass3_results.md   -- the Test Results, with the Recommendation as the last
                          chapter (the deliverable, section 10).

Section-8 measures and how each is realized here (all binding; the ones that are
structurally not applicable to a single-pass, bed2-only Pass-3 run are NAMED as
such with the reason, never silently dropped):
  hallucination, legal-correctness (bed2), coverage, batch integrity/drops,
  schema validity, cross-model agreement (n/a: one model), cost (measured from the
  per-call tokens the tool surfaces, at long-context rates), reliability (retest
  drops measured; structured-output re-asks FLAGGED -- not exposed per call),
  resolution yield, residue accuracy (vs an
  operator-supplied hand-verified sample), consistency (2-pass + bed3 parts n/a to
  Pass 3; the Pass-3 insert-vs-bare crosswalk delta is computed for section 12).
"""

from __future__ import annotations

import json
import pathlib
import sys
from collections import Counter, defaultdict

_ROOT = pathlib.Path(r"c:\CHATHealthyLLC")
_PIPELINE_DIR = _ROOT / "pipeline" / "MedicareProviderEvaluationDataPipeline"
_LIB_SRC = _ROOT / "ChatHealthyLib" / "src"
for _p in (str(_ROOT), str(_LIB_SRC), str(_PIPELINE_DIR)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from chathealthy_lib.exceptions import ChatHealthyException
from chathealthy_lib.logging_service import ChatHealthyLoggingService

import fda_drug_enrichment_tool as tool_module
from fda_drug_enrichment_tool import FDADrugEnrichmentTool

_log = ChatHealthyLoggingService()

# gpt-5.6-luna long-context published rates (section 6 / Appendix D), dollars per
# token. Cost (section 8) is computed from the tokens the tool now surfaces.
_RATE_PER_TOKEN_INPUT = 0.20 / 1_000_000
_RATE_PER_TOKEN_OUTPUT = 1.20 / 1_000_000
_FULL_BUILD_SPLS = 250_000   # section: production record_number runs 1..~250K

HARNESS = _ROOT / "_oneshots" / "medicare_benchmark" / "harness"
BED2_PATH = HARNESS / "benchmark_sample_v2.jsonl"
CATALOG_PATH = _ROOT / "_oneshots" / "medicare_benchmark" / "icd10_categories_top3levels.xlsx"
SCRATCH_DIR = HARNESS / "pass3_scratch"
SCORES_JSON = HARNESS / "pass3_scores.json"
RESULTS_MD = HARNESS / "pass3_results.md"

CANDIDATE_MODEL = "gpt-5.6-luna"
PRIMARY_ARM = "insert"   # the production-faithful crosswalk arm (section 11)

# OPTIONAL, OPERATOR-SUPPLIED: a hand-verified truth sample for residue (tier-3)
# accuracy (section 5 / section 8: "scored against a hand-verified sample"). A
# JSONL of {"id": <batch id or set_id>, "ingredient_rxcui": "<correct rxcui>"}.
# Absent -> residue accuracy is reported as pending, with the residue SET listed
# so it can be hand-verified. The molecule-level truth in molecules.jsonl is NOT
# substituted for it here (that would be an automated proxy, not hand-verified).
RESIDUE_TRUTH_PATH = HARNESS / "pass3_residue_truth.jsonl"   # sentinel; may not exist


# ─────────────────────────────────────────────────────────────────────────────
# Loaders.
# ─────────────────────────────────────────────────────────────────────────────
def _load_json(path: pathlib.Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _num(value) -> float:
    """A numeric token count, or 0 when absent/non-numeric."""
    return value if isinstance(value, (int, float)) else 0


def load_bed2_by_position() -> dict:
    """position (0-based) -> bed2 row. record_number = position + 1."""
    rows = [json.loads(line) for line in BED2_PATH.read_text(encoding="utf-8").splitlines()
            if line.strip()]
    return {i: row for i, row in enumerate(rows)}


def load_scratch():
    """Return (prompt1_envelopes, prompt2_by_arm). Raise if no scratch exists."""
    if not SCRATCH_DIR.is_dir():
        raise ChatHealthyException(
            mode="config_error", component="pass3_score",
            message=(f"no scratch directory at {SCRATCH_DIR}; run pass3_run.py first. "
                     "The scorer reads only persisted raw results."))
    p1 = sorted(SCRATCH_DIR.glob("p3__b*__prompt1.json"))
    p2 = defaultdict(list)
    for path in sorted(SCRATCH_DIR.glob("p3__b*__prompt2_*.json")):
        env = _load_json(path)
        p2[env.get("arm")].append(env)
    if not p1 and not any(p2.values()):
        raise ChatHealthyException(
            mode="config_error", component="pass3_score",
            message=f"{SCRATCH_DIR} holds no Pass-3 scratch files; nothing to score.")
    return [_load_json(p) for p in p1], dict(p2)


def _codes_of(result: dict) -> list:
    return [c.get("icd10_code") for ind in result.get("indications", [])
            for c in ind.get("codes", [])]


def _is_combination(row: dict) -> bool:
    """True when a bed2 row names a multi-ingredient combination drug -- the real
    ingredient situation, read from the molecule name's combination marker ('+')
    or a molecule_key carrying more than one ingredient. This is the SOURCE marker
    for a combination; a resolution also marks one by producing more than one
    ingredient_rxcuis entry (Amendment 3). A combination now joins on its full
    ingredient_rxcuis array and is no longer floored for having more than one."""
    if not row:
        return False
    if "+" in str(row.get("molecule_id") or ""):
        return True
    key = row.get("molecule_key")
    return isinstance(key, list) and len(key) > 1


# ─────────────────────────────────────────────────────────────────────────────
# Scoring.
# ─────────────────────────────────────────────────────────────────────────────
def _merge_arm(p2_envelopes: list) -> tuple:
    """Return (results_by_record_number, drop_stats) for one crosswalk arm,
    joining each result to its bed2 row via record_number."""
    by_rn: dict = {}
    drop = {"batches": 0, "initial_drops": 0, "finally_lost": 0, "recovered": 0,
            "retest_rounds_used": 0}
    for env in p2_envelopes:
        drop["batches"] += 1
        id_to_rn = {str(k): v for k, v in (env.get("id_to_record_number") or {}).items()}
        rounds = env.get("rounds") or []
        expected = set(str(x) for x in (env.get("input_ids") or []))
        round0_returned = set()
        all_returned = set()
        for r in rounds:
            got = set(str(x) for x in (r.get("returned_ids") or []))
            all_returned |= got
            if r.get("round") == 0:
                round0_returned = got
            if r.get("round", 0) > 0 and r.get("fired_ids"):
                drop["retest_rounds_used"] += 1
        finally_lost = set(str(x) for x in (env.get("dropped_after_retest") or []))
        initial = expected - round0_returned
        drop["initial_drops"] += len(initial)
        drop["finally_lost"] += len(finally_lost)
        drop["recovered"] += len(initial & all_returned)
        for result in (env.get("output") or {}).get("results") or []:
            rid = str(result.get("id"))
            rn = id_to_rn.get(rid)
            if rn is not None:
                by_rn[int(rn)] = result
    return by_rn, drop


def score(prompt1_envelopes: list, prompt2_by_arm: dict, bed2: dict) -> dict:
    tool = FDADrugEnrichmentTool(catalog=str(CATALOG_PATH))
    catalog = tool.catalog_codes    # local xlsx read; no network

    arms = {}
    for arm, envs in prompt2_by_arm.items():
        arms[arm] = _merge_arm(envs)
    primary = arms.get(PRIMARY_ARM, ({}, {}))
    primary_by_rn, primary_drop = primary

    # ---- MEASURE: hallucination, coverage, schema (primary = production-faithful arm)
    returned_codes = out_of_catalog = 0
    n_results = n_covered = 0
    conf_bad = rationale_missing = usage_missing = n_indications = 0
    for rn, result in primary_by_rn.items():
        n_results += 1
        codes = _codes_of(result)
        returned_codes += len(codes)
        out_of_catalog += sum(1 for c in codes if c not in catalog)
        has_code = any(ind.get("codes") for ind in result.get("indications", []))
        if result.get("indications") and has_code:
            n_covered += 1
        if not (result.get("usage_summary") or "").strip():
            usage_missing += 1
        for ind in result.get("indications", []):
            n_indications += 1
            if not (ind.get("confidence_rationale") or "").strip():
                rationale_missing += 1
            for c in ind.get("codes", []):
                cv = c.get("confidence")
                if not (isinstance(cv, (int, float)) and 0.0 <= cv <= 1.0):
                    conf_bad += 1

    hallucination = {
        "returned_codes": returned_codes, "out_of_catalog": out_of_catalog,
        "hallucination_rate": round(out_of_catalog / max(1, returned_codes), 4),
        "disqualifying": out_of_catalog > 0,
        "note": "section 8: inventing any out-of-catalog code disqualifies a model.",
    }
    coverage = {"results": n_results, "covered": n_covered,
                "coverage": round(n_covered / max(1, n_results), 4)}
    schema = {"results": n_results, "indications": n_indications,
              "confidence_out_of_range": conf_bad,
              "indications_missing_rationale": rationale_missing,
              "results_missing_usage_summary": usage_missing,
              "schema_valid": conf_bad == 0 and rationale_missing == 0 and usage_missing == 0}

    # ---- MEASURE: legal-correctness (bed2) -- generic subset-of-brand per molecule
    brand_pool = defaultdict(set)
    generics = defaultdict(list)
    for rn, result in primary_by_rn.items():
        row = bed2.get(rn - 1)
        if not row:
            continue
        mol = row.get("molecule_id")
        codeset = set(_codes_of(result))
        if row.get("kind") == "brand":
            brand_pool[mol] |= codeset
        elif row.get("kind") == "generic":
            generics[mol].append((rn, codeset))
    identical = subset = divergent = total = skipped = 0
    for mol, gens in generics.items():
        if not brand_pool.get(mol):
            skipped += 1
            continue
        ref = brand_pool[mol]
        for _rn, codeset in gens:
            total += 1
            if codeset == ref:
                identical += 1
            elif codeset <= ref:
                subset += 1
            else:
                divergent += 1
    legal = {"generics_classified": total, "identical": identical, "subset": subset,
             "superset_or_divergent": divergent,
             "pass_rate": round((identical + subset) / max(1, total), 4),
             "molecules_skipped_no_brand_ref": skipped}

    # ---- MEASURE: resolution yield + floor by reason (from PROMPT 1 raw)
    tier_counts = Counter()
    floor_reasons = Counter()
    residue_items = []      # tier3 picks (the inference set)
    floor_items = []        # unresolvable
    total_resolved = 0
    join_key_resolved = 0       # ingredient_rxcuis non-empty (a usable join key)
    tier3_with_join_key = 0
    tier3_without_join_key = 0
    for env in prompt1_envelopes:
        id_to_set = env.get("id_to_set_id") or {}
        id_to_rn = {str(k): v for k, v in (env.get("id_to_record_number") or {}).items()}
        for item in (env.get("output") or {}).get("results") or []:
            total_resolved += 1
            by = item.get("resolved_by")
            tier_counts[by] += 1
            ingredient_rxcuis = item.get("ingredient_rxcuis") or []
            has_join_key = bool(ingredient_rxcuis)
            if has_join_key:
                join_key_resolved += 1
            row = bed2.get(int(id_to_rn[str(item.get("id"))]) - 1) if str(item.get("id")) in id_to_rn else None
            rec = {"id": item.get("id"), "set_id": id_to_set.get(str(item.get("id"))),
                   "rxcui": item.get("rxcui"), "ingredient_rxcuis": ingredient_rxcuis,
                   "confidence": item.get("confidence"),
                   "confidence_rationale": item.get("confidence_rationale"),
                   "molecule": (row or {}).get("molecule_id"),
                   # Amendment 3: a combination is a record whose resolution produced
                   # >1 ingredient OR whose source row marks it a combination.
                   "combination": (len(ingredient_rxcuis) > 1) or _is_combination(row),
                   "has_join_key": has_join_key}
            if by == "tier3":
                residue_items.append(rec)
                if has_join_key:
                    tier3_with_join_key += 1
                else:
                    tier3_without_join_key += 1
            elif by == "floor":
                floor_items.append(rec)
                floor_reasons[(item.get("confidence_rationale") or "unspecified")[:120]] += 1
    deterministic = tier_counts.get("tier1", 0) + tier_counts.get("tier2", 0)
    resolution_yield = {
        "total_drugs": total_resolved,
        "tier1": tier_counts.get("tier1", 0), "tier2": tier_counts.get("tier2", 0),
        "tier3": tier_counts.get("tier3", 0), "floor": tier_counts.get("floor", 0),
        "deterministic_count": deterministic,
        "deterministic_yield": round(deterministic / max(1, total_resolved), 4),
        # rxcui-FOUND share (a tier-3 pick found an RXCUI), which is NOT the same as
        # join coverage: a tier-3 pick can find an RXCUI yet resolve no tty=IN
        # ingredient, leaving an empty ingredient_rxcuis array (no join key).
        "inference_share": round(tier_counts.get("tier3", 0) / max(1, total_resolved), 4),
        "tier3_with_join_key": tier3_with_join_key,
        "tier3_without_join_key": tier3_without_join_key,
        # TRUE join coverage: how many records carry a usable join key (a non-empty
        # ingredient_rxcuis array), counted separately so inference_share does not
        # overstate join coverage (M2).
        "join_key_resolved": join_key_resolved,
        "join_key_coverage": round(join_key_resolved / max(1, total_resolved), 4),
        "join_key_coverage_note": ("join_key_coverage counts records with a non-empty "
                                   "ingredient_rxcuis array; a combination now carries its full "
                                   "ingredient set and IS join-resolved. Only records that "
                                   "resolved no tty=IN ingredient (empty array) are excluded."),
        "floor_share": round(tier_counts.get("floor", 0) / max(1, total_resolved), 4),
        "floor_reason_buckets": dict(floor_reasons),
    }

    # ---- MEASURE: residue accuracy (tier-3) vs an operator hand-verified sample
    residue_accuracy = _residue_accuracy(residue_items)

    # ---- MEASURE: batch integrity / drops (primary arm)
    drops = primary_drop

    # ---- MEASURE: consistency -- the parts that need 2 passes or bed3 are n/a to
    #      Pass 3; the Pass-3 insert-vs-bare crosswalk delta is computed (section 12).
    insert_vs_bare = _insert_vs_bare(arms, prompt2_by_arm)
    consistency = {
        "two_pass_determinism": None,
        "two_pass_note": ("not applicable to Pass 3: section 11 runs the candidate in a single "
                          "pass over bed2. Cross-pass determinism is a passes-1/2 measure "
                          "(section 7, two independent passes)."),
        "bed2_vs_bed3_union": None,
        "bed3_note": ("not applicable to Pass 3: section 11 uses the bed2 sample only; the "
                      "per-SPL-union-vs-bed3 reconstruction is a passes-1/2 measure."),
        "insert_vs_bare_crosswalk": insert_vs_bare,
    }

    # ---- MEASURE: cross-model agreement -- single model
    cross_model_agreement = {
        "value": None,
        "note": "not applicable: Pass 3 runs one model (gpt-5.6-luna); there is no second model "
                "to form a consensus against (section 8).",
    }

    # ---- MEASURE: cost -- from the tokens the tool now surfaces (section 8)
    total_elapsed = sum(float(e.get("elapsed_seconds") or 0) for e in prompt1_envelopes)
    for v in prompt2_by_arm.values():
        total_elapsed += sum(float(e.get("elapsed_seconds") or 0) for e in v)
    # Production fires PROMPT 1 then the production-faithful (insert) PROMPT 2 once
    # per SPL; the bare arm is a test-only measurement arm, excluded from cost.
    cost_envelopes = list(prompt1_envelopes) + list(prompt2_by_arm.get(PRIMARY_ARM, []))
    cost_in = cost_out = cost_cached = 0
    any_tokens = False
    for env in cost_envelopes:
        usage = env.get("usage") or {}
        if usage.get("available"):
            any_tokens = True
        cost_in += _num(usage.get("input_tokens"))
        cost_out += _num(usage.get("output_tokens"))
        cost_cached += _num(usage.get("cached_input_tokens"))
    dollars_total = cost_in * _RATE_PER_TOKEN_INPUT + cost_out * _RATE_PER_TOKEN_OUTPUT
    spls_costed = n_results
    dollars_per_spl = dollars_total / max(1, spls_costed)
    cost = {
        "measurable": bool(any_tokens),
        "input_tokens": cost_in, "output_tokens": cost_out, "cached_input_tokens": cost_cached,
        "rate_per_1m_input": 0.20, "rate_per_1m_output": 1.20,
        "spls_costed": spls_costed,
        "dollars_total": round(dollars_total, 6),
        "dollars_per_spl": round(dollars_per_spl, 6),
        "dollars_per_1000": round(dollars_per_spl * 1000, 4),
        "dollars_per_full_build": round(dollars_per_spl * _FULL_BUILD_SPLS, 2),
        "full_build_spls": _FULL_BUILD_SPLS,
        "note": ("section 8 cost at gpt-5.6-luna long-context published rates (0.20/1M input, "
                 f"1.20/1M output; section 6 / Appendix D), over PROMPT 1 plus the production-"
                 f"faithful '{PRIMARY_ARM}' PROMPT 2 arm (the bare arm is a test-only measurement "
                 "arm, excluded). cached_input_tokens are reported separately; no cache-discount "
                 "rate is published, so the input rate is applied to all input tokens -- an upper "
                 "bound given the ~free cached catalog prefix (section 5)."),
    }
    reliability = {
        "retest_rounds_used_primary_arm": drops.get("retest_rounds_used", 0),
        "initially_dropped_primary_arm": drops.get("initial_drops", 0),
        "recovered_by_retest_primary_arm": drops.get("recovered", 0),
        "finally_lost_primary_arm": drops.get("finally_lost", 0),
        "structured_output_reasks": None,
        "reask_note": ("per-call structured-output re-asks are counted inside the tool's "
                       "_run_agent and not exposed by its public interface; FLAGGED. Retest-on-"
                       "drop rounds (harness-side) ARE measured above."),
    }

    # ---- throughput / time (section 12)
    throughput = {
        "sum_call_elapsed_seconds": round(total_elapsed, 3),
        "note": ("sum of per-call wall-clock across PROMPT 1 and both PROMPT-2 arms; with the "
                 "5-thread fan-out, wall-clock run time is shorter than this sum. Full-build "
                 "projection at production volume is left to the recommendation chapter once "
                 "production SPL count and the rate limit are set."),
    }

    recommendation = _recommendation(resolution_yield, residue_items, floor_items,
                                     floor_reasons, insert_vs_bare, hallucination, legal,
                                     coverage, schema, cost, throughput, drops, bed2)

    return {
        "candidate_model": CANDIDATE_MODEL,
        "primary_arm": PRIMARY_ARM,
        "sample": {"scored_results_primary_arm": n_results,
                   "prompt1_batches": len(prompt1_envelopes),
                   "prompt2_arms": sorted(prompt2_by_arm)},
        "measures": {
            "hallucination": hallucination,
            "legal_correctness_bed2": legal,
            "coverage": coverage,
            "batch_integrity_drops": drops,
            "schema_validity": schema,
            "cross_model_agreement": cross_model_agreement,
            "cost": cost,
            "reliability": reliability,
            "resolution_yield": resolution_yield,
            "residue_accuracy": residue_accuracy,
            "consistency": consistency,
            "throughput": throughput,
        },
        "recommendation": recommendation,
    }


def _residue_accuracy(residue_items: list) -> dict:
    if not RESIDUE_TRUTH_PATH.is_file():
        return {
            "measurable": False,
            "residue_count": len(residue_items),
            "reason": (f"no hand-verified truth at {RESIDUE_TRUTH_PATH.name}; section 8 requires a "
                       "hand-verified sample. The residue set (tier-3 picks) is listed so it can be "
                       "hand-verified; the molecule-level truth in molecules.jsonl is NOT "
                       "substituted (it is an automated proxy, not hand-verification)."),
            "residue_set": residue_items,
        }
    truth = {}
    for line in RESIDUE_TRUTH_PATH.read_text(encoding="utf-8").splitlines():
        if line.strip():
            row = json.loads(line)
            key = str(row.get("set_id") or row.get("id"))
            truth[key] = str(row.get("ingredient_rxcui"))
    judged = correct = 0
    misses = []
    for item in residue_items:
        key = str(item.get("set_id") or item.get("id"))
        if key not in truth:
            continue
        judged += 1
        picked = [str(x) for x in (item.get("ingredient_rxcuis") or [])]
        # A combination resolves to a set; the hand-verified ingredient is correct
        # when it is among the resolved tty=IN ingredients.
        if truth[key] in picked:
            correct += 1
        else:
            misses.append({"key": key, "picked": item.get("ingredient_rxcuis"),
                           "truth": truth[key]})
    return {
        "measurable": True, "residue_count": len(residue_items),
        "judged_against_truth": judged, "correct": correct,
        "accuracy": round(correct / max(1, judged), 4), "misses": misses,
    }


def _insert_vs_bare(arms: dict, prompt2_by_arm: dict) -> dict:
    """Crosswalk quality WITH vs WITHOUT the inserted rxcui (section 12): compare
    the two arms' code sets, restricted to the SPLs that actually received an
    inserted rxcui in the insert arm (the only ones where the arms can differ by
    design)."""
    if "insert" not in arms or "bare" not in arms:
        return {"measurable": False,
                "reason": "both the 'insert' and 'bare' crosswalk arms are required; "
                          f"present arms: {sorted(arms)}."}
    inserted_ids = set()
    insert_rn_by_id = {}
    for env in prompt2_by_arm.get("insert", []):
        id_to_rn = {str(k): v for k, v in (env.get("id_to_record_number") or {}).items()}
        for rid in env.get("inserted_rxcui_ids") or []:
            rn = id_to_rn.get(str(rid))
            if rn is not None:
                inserted_ids.add(int(rn))
                insert_rn_by_id[int(rn)] = rid
    insert_by_rn = arms["insert"][0]
    bare_by_rn = arms["bare"][0]
    jaccs, exacts, changed = [], [], 0
    for rn in sorted(set(insert_by_rn) & set(bare_by_rn)):
        a = set(_codes_of(insert_by_rn[rn]))
        b = set(_codes_of(bare_by_rn[rn]))
        only_inserted = rn in inserted_ids
        if a == b and not a:
            jacc = 1.0
        else:
            jacc = len(a & b) / max(1, len(a | b))
        exact = 1.0 if a == b else 0.0
        if only_inserted:
            jaccs.append(jacc)
            exacts.append(exact)
            if a != b:
                changed += 1
    return {
        "measurable": True,
        "spls_with_inserted_rxcui": len(inserted_ids),
        "spls_compared": len(jaccs),
        "mean_jaccard_insert_vs_bare": round(sum(jaccs) / len(jaccs), 4) if jaccs else None,
        "exact_match_rate_insert_vs_bare": round(sum(exacts) / len(exacts), 4) if exacts else None,
        "spls_whose_codes_changed": changed,
        "note": ("restricted to SPLs that received an inserted rxcui (confidence above the tool's "
                 "insert threshold); these are the only SPLs where the two arms' inputs differ."),
    }


def _recommendation(resolution_yield, residue_items, floor_items, floor_reasons,
                    insert_vs_bare, hallucination, legal, coverage, schema, cost,
                    throughput, drops, bed2) -> dict:
    """Section 12 synthesis: deterministic yield; the residue + floor failure set
    and whether misses cluster on low-value drugs; crosswalk effect of the inserted
    rxcui; cost/time/throughput. States the funnel settings and the known failure
    set."""
    # The failure set keys on the REAL ingredient situation (M2): an EMPTY
    # ingredient_rxcuis array (every floor, plus any tier-3 pick that resolved no
    # tty=IN ingredient). A combination is NO LONGER a miss by construction -- it
    # joins on its full ingredient set -- so it counts here only if its array came
    # back empty. The combination marker still reads from the source row / a >1
    # ingredient resolution, never from a '+' in a numeric id or UUID.
    null_join_items = list(floor_items) + [r for r in residue_items if not r.get("has_join_key")]
    combo_null_join = sum(1 for it in null_join_items if it.get("combination"))
    combo_floor = sum(1 for it in floor_items if it.get("combination"))
    tier3_no_join = sum(1 for r in residue_items if not r.get("has_join_key"))
    failure_set = {
        "floor_count": len(floor_items),
        "floor_reason_buckets": dict(floor_reasons),
        "tier3_residue_count": len(residue_items),
        "tier3_without_join_key_count": tier3_no_join,
        "null_join_key_count": len(null_join_items),
        "combination_share_of_null_join_key": (
            round(combo_null_join / len(null_join_items), 4) if null_join_items else None),
        "combination_share_of_floor": (
            round(combo_floor / len(floor_items), 4) if floor_items else None),
        "note": ("the misses are read from the real ingredient situation -- records whose "
                 "ingredient_rxcuis array came back empty -- not from any '+' in a numeric id or "
                 "UUID. A combination joins on its full ingredient set and is a miss only if its "
                 "array is empty. A high combination share means the misses are the drugs that "
                 "matter least."),
    }
    combination_drug_consequence = {
        "statement": ("A multi-ingredient combination drug has more than one tty=IN ingredient; "
                      "its resolution now carries the FULL set in the ingredient_rxcuis array and "
                      "joins on every one. A combination is no longer floored for having more than "
                      "one ingredient -- it is join-resolved whenever its ingredient_rxcuis array "
                      "is non-empty, and enriches in place as before."),
        "null_join_key_count": len(null_join_items),
        "combination_share_of_null_join_key": (
            round(combo_null_join / len(null_join_items), 4) if null_join_items else None),
        "schema_note": ("ingredient_rxcuis is an array of tty=IN RXCUIs (operator-approved "
                        "Amendment 3); a combination joins on its full ingredient set, and an "
                        "unresolved join is an empty array rather than a floor by construction."),
    }
    return {
        "combination_drug_consequence": combination_drug_consequence,
        "deterministic_yield": {
            "value": resolution_yield["deterministic_yield"],
            "verdict": ("a high deterministic yield (tiers 1-2, no model) is the strongest signal "
                        "the map is trustworthy; this is the share resolved with no inference."),
        },
        "failure_set": failure_set,
        "inserted_rxcui_effect": insert_vs_bare,
        "quality_gates": {
            "hallucination_disqualifying": hallucination["disqualifying"],
            "legal_pass_rate_bed2": legal["pass_rate"],
            "coverage": coverage["coverage"],
            "schema_valid": schema["schema_valid"],
        },
        "cost_time_throughput": {
            "cost": cost,
            "throughput": throughput,
            "drops": drops,
        },
        "funnel_settings": {
            "candidate_model": CANDIDATE_MODEL,
            "insert_threshold": (f"rxcui inserted into the crosswalk only above "
                                 f"{tool_module._INSERT_THRESHOLD}; tiers 1-2 are confidence 1 "
                                 f"and always insert."),
        },
        "statement": ("The recommendation weighs these Pass-3 facts together with the passes-1/2 "
                      "correctness, legal-correctness, consistency, and cost scores (not in this "
                      "file) and states the model, the funnel settings including the "
                      f"{tool_module._INSERT_THRESHOLD} insert threshold, and the known failure "
                      "set above. Cost is measured from the tool's surfaced per-call tokens "
                      "(section 8)."),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Deliverable rendering.
# ─────────────────────────────────────────────────────────────────────────────
def _render_md(scores: dict) -> str:
    m = scores["measures"]
    rec = scores["recommendation"]
    lines = []
    lines.append("# NormalizedIndicationMap - Pass 3 Test Results")
    lines.append("")
    lines.append(f"Candidate model: **{scores['candidate_model']}** (section 11). "
                 f"Primary (production-faithful) crosswalk arm: **{scores['primary_arm']}**.")
    lines.append(f"Scored results (primary arm): {scores['sample']['scored_results_primary_arm']}; "
                 f"PROMPT 1 batches: {scores['sample']['prompt1_batches']}; "
                 f"PROMPT 2 arms: {', '.join(scores['sample']['prompt2_arms'])}.")
    lines.append("")
    lines.append("## Section 8 measures")
    lines.append("")
    for name, body in m.items():
        lines.append(f"### {name}")
        lines.append("```json")
        lines.append(json.dumps(body, indent=2, ensure_ascii=False))
        lines.append("```")
        lines.append("")
    lines.append("## Recommendation (section 12)")
    lines.append("")
    lines.append("```json")
    lines.append(json.dumps(rec, indent=2, ensure_ascii=False))
    lines.append("```")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    bed2 = load_bed2_by_position()
    prompt1_envelopes, prompt2_by_arm = load_scratch()
    scores = score(prompt1_envelopes, prompt2_by_arm, bed2)
    SCORES_JSON.write_text(json.dumps(scores, indent=2, ensure_ascii=False), encoding="utf-8")
    RESULTS_MD.write_text(_render_md(scores), encoding="utf-8")
    _log.LogPipeline("INFO", "pass3_score: wrote %s and %s", SCORES_JSON.name, RESULTS_MD.name)
    _log.LogPipeline(
        "INFO",
        "pass3_score: deterministic_yield=%s halluc_disqualifying=%s legal_pass=%s coverage=%s",
        scores["measures"]["resolution_yield"]["deterministic_yield"],
        scores["measures"]["hallucination"]["disqualifying"],
        scores["measures"]["legal_correctness_bed2"]["pass_rate"],
        scores["measures"]["coverage"]["coverage"])


if __name__ == "__main__":
    main()
