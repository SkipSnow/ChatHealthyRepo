"""Pass 3 LOCAL end-to-end job. Stages REAL openFDA drug labels (only labels that
actually carry openfda.rxcui AND indications), runs them through the production
FDADrugEnrichmentTool (PROMPT 1 resolution -> PROMPT 2 crosswalk), builds the
NormalizedIndicationMap records, and emits a result + recommendation. Local,
end-to-end, bounded. Fires luna + RxNav (operator-authorized). One-off in _oneshots."""
import os
import sys
import json
import time
import pathlib
import collections
import urllib.request

ROOT = pathlib.Path(r"c:\CHATHealthyLLC")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "ChatHealthyLib" / "src"))
sys.path.insert(0, str(ROOT / "pipeline" / "MedicareProviderEvaluationDataPipeline"))
for line in (ROOT / ".env").read_text(encoding="utf-8", errors="replace").splitlines():
    if "=" in line and not line.strip().startswith("#"):
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())

N = int(os.environ.get("PASS3_N", "50"))
SCRATCH = ROOT / "_oneshots" / "medicare_benchmark" / "harness" / "pass3_local_scratch"
SCRATCH.mkdir(parents=True, exist_ok=True)
CATALOG = ROOT / "_oneshots" / "medicare_benchmark" / "icd10_categories_top3levels.xlsx"
API = "https://api.fda.gov/drug/label.json"
QUERY = "_exists_:indications_and_usage"  # real drug labels; do NOT require rxcui (no-rxcui labels are the tier-3/floor cases)


def stage_real_labels(n):
    staged, skip = [], 0
    print(f"STAGING: fetching {n} real openFDA drug labels (indications + set_id; rxcui NOT required) ...", flush=True)
    while len(staged) < n and skip < 5000:
        url = f"{API}?search={QUERY}&limit=100&skip={skip}"
        try:
            r = json.load(urllib.request.urlopen(url, timeout=45))
        except Exception as e:  # noqa: BLE001
            print(f"  fetch error at skip={skip}: {repr(e)[:140]}", flush=True)
            break
        res = r.get("results", [])
        if not res:
            break
        for d in res:
            of = d.get("openfda") or {}
            if (of.get("rxcui") and d.get("indications_and_usage") and d.get("set_id")):
                staged.append(d)
                if len(staged) >= n:
                    break
        skip += 100
        time.sleep(0.4)
    print(f"  staged {len(staged)} real labels", flush=True)
    return staged[:n]


labels = stage_real_labels(N)
if not labels:
    print("FATAL: staged 0 labels; cannot run.", flush=True)
    sys.exit(2)
(SCRATCH / "staged_labels.json").write_text(json.dumps(labels), encoding="utf-8")

records = []
otc_excluded = 0
for d in labels:
    of = d.get("openfda") or {}
    # MAP SCOPE (operator policy): prescription drugs only. We do NOT code OTC medicines.
    # OTC labels are staged but excluded from the map. openfda.product_type is the discriminator
    # ("HUMAN OTC DRUG" vs "HUMAN PRESCRIPTION DRUG").
    ptypes = [str(x).upper() for x in (of.get("product_type") or [])]
    if any("OTC" in pt for pt in ptypes):
        otc_excluded += 1
        continue
    subs = of.get("substance_name") or of.get("generic_name") or []
    molecule = " + ".join(subs) if subs else ((of.get("brand_name") or ["UNKNOWN"])[0] or "UNKNOWN")
    iau = d.get("indications_and_usage") or []
    indication_text = " ".join(iau) if isinstance(iau, list) else str(iau)
    records.append({"set_id": d.get("set_id"), "id": d.get("id"),
                    "molecule": molecule, "indication_text": indication_text, "openfda": of})

print(f"RUNNING FDADrugEnrichmentTool (gpt-5.6-luna) over {len(records)} staged records ...", flush=True)
import fda_drug_enrichment_tool as T  # noqa: E402

tool = T.FDADrugEnrichmentTool(model="gpt-5.6-luna", catalog=str(CATALOG))
t0 = time.time()
maprecs = tool.enrich(records)
elapsed = time.time() - t0
(SCRATCH / "map_records.jsonl").write_text(
    "\n".join(json.dumps(r.model_dump()) for r in maprecs), encoding="utf-8")

by_tier = collections.Counter(r.resolved_by for r in maprecs)
join_resolved = sum(1 for r in maprecs if r.ingredient_rxcuis)
with_codes = sum(1 for r in maprecs if any(ind.codes for ind in r.indications))
n_ind = sum(len(r.indications) for r in maprecs)
n_codes = sum(len(ind.codes) for r in maprecs for ind in r.indications)
print("=========== RESULT ===========", flush=True)
print(f"records built: {len(maprecs)} in {elapsed:.0f}s", flush=True)
print(f"resolution by tier: {dict(by_tier)}", flush=True)
print(f"join-key resolved (ingredient_rxcuis non-empty): {join_resolved}/{len(maprecs)} "
      f"({100*join_resolved/len(maprecs):.0f}%)", flush=True)
print(f"records with >=1 ICD-10 code: {with_codes}/{len(maprecs)} "
      f"({100*with_codes/len(maprecs):.0f}%)", flush=True)
print(f"total indications: {n_ind} | total ICD-10 codes: {n_codes}", flush=True)
print(f"last resolution-call usage: {tool.last_resolution_usage()}", flush=True)
print(f"last crosswalk-call usage:  {tool.last_crosswalk_usage()}", flush=True)
print("DONE end-to-end: staged real openFDA -> resolved -> crosswalked -> map records.", flush=True)
