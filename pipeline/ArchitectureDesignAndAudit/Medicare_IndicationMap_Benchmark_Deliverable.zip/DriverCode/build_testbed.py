"""
openFDA drug-label -> molecule test bed builder. Data-prep only.
NO model calls, NO git, NO Mongo. Everything under _oneshots/medicare_benchmark/.
"""
import os, sys, json, zipfile, hashlib, time, traceback
import requests
import ijson

BASE = r"c:\CHATHealthyLLC\_oneshots\medicare_benchmark"
TMP = os.path.join(BASE, "_pull_tmp")
TESTBED = os.path.join(BASE, "testbed")
INDEX_URL = "https://api.fda.gov/download.json"

os.makedirs(TMP, exist_ok=True)
os.makedirs(TESTBED, exist_ok=True)

def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)

# ---- 1. index ----
log("Fetching download index...")
idx = requests.get(INDEX_URL, timeout=120).json()
dl = idx["results"]["drug"]["label"]
export_date = dl["export_date"]
total_records = dl["total_records"]
partitions = dl["partitions"]
log(f"export_date={export_date} total_records={total_records} partitions={len(partitions)}")

partition_meta = [{"file": p["file"], "size_mb": p.get("size_mb"),
                   "records": p.get("records"), "display_name": p.get("display_name")}
                  for p in partitions]

# ---- molecule accumulator ----
molecules = {}   # key tuple -> aggregate dict
total_labels = 0
skipped_empty_substance = 0
partition_report = []

def classify_kind(app_numbers):
    # list of application_number strings. ANDA->generic (checked first),
    # NDA/BLA->brand, else other.
    anda = False
    brandish = False
    for a in app_numbers:
        au = a.strip().upper()
        if au.startswith("ANDA"):
            anda = True
        elif au.startswith("NDA") or au.startswith("BLA"):
            brandish = True
    if anda:
        return "generic"
    if brandish:
        return "brand"
    return "other"

def get_mol(key_tuple):
    m = molecules.get(key_tuple)
    if m is None:
        m = {"substances": list(key_tuple), "rxcuis": set(),
             "distinct_prose": [], "prose_index": {}, "labels": []}
        molecules[key_tuple] = m
    return m

def intern_prose(m, prose):
    # returns index into distinct_prose, or -1 if empty
    if not prose:
        return -1
    pi = m["prose_index"].get(prose)
    if pi is None:
        pi = len(m["distinct_prose"])
        m["distinct_prose"].append(prose)
        m["prose_index"][prose] = pi
    return pi

def process_record(rec):
    global total_labels, skipped_empty_substance
    total_labels += 1
    ofda = rec.get("openfda") or {}
    subs = ofda.get("substance_name") or []
    key = tuple(sorted(set(s.strip().upper() for s in subs if s and s.strip())))
    if not key:
        skipped_empty_substance += 1
        return
    m = get_mol(key)
    # rxcui
    for rc in (ofda.get("rxcui") or []):
        if rc and str(rc).strip():
            m["rxcuis"].add(str(rc).strip())
    # indications prose for this label
    iau = rec.get("indications_and_usage") or []
    prose = " ".join(x for x in iau if x).strip()
    app_numbers = ofda.get("application_number") or []
    kind = classify_kind(app_numbers)
    pi = intern_prose(m, prose)
    m["labels"].append({"application_number": list(app_numbers),
                        "kind": kind, "prose_idx": pi})

def download(url, dest, attempts=3):
    last = None
    for a in range(1, attempts + 1):
        try:
            with requests.get(url, stream=True, timeout=300) as r:
                r.raise_for_status()
                with open(dest, "wb") as f:
                    for chunk in r.iter_content(chunk_size=1024 * 1024):
                        if chunk:
                            f.write(chunk)
            return True
        except Exception as e:
            last = e
            log(f"  download attempt {a} failed: {e}")
            time.sleep(2 * a)
    raise last

# ---- 2+3. per-partition stream ----
for i, p in enumerate(partitions, 1):
    url = p["file"]
    fn = url.rsplit("/", 1)[-1]
    dest = os.path.join(TMP, fn)
    rep = {"file": url, "size_mb": p.get("size_mb"), "expected_records": p.get("records")}
    try:
        log(f"[{i}/{len(partitions)}] downloading {fn} ({p.get('size_mb')} MB)...")
        download(url, dest)
        before = total_labels
        with zipfile.ZipFile(dest) as z:
            inner = z.namelist()[0]
            with z.open(inner) as stream:
                for rec in ijson.items(stream, "results.item"):
                    process_record(rec)
        parsed = total_labels - before
        rep["parsed_records"] = parsed
        rep["status"] = "ok"
        log(f"    parsed {parsed} records (running labels={total_labels}, molecules={len(molecules)})")
    except Exception as e:
        rep["status"] = "error"
        rep["error"] = repr(e)
        log(f"    PARTITION ERROR: {e}")
        traceback.print_exc()
    finally:
        try:
            if os.path.exists(dest):
                os.remove(dest)
        except Exception as e:
            log(f"    could not delete {dest}: {e}")
    partition_report.append(rep)

log(f"ALL PARTITIONS DONE. total_labels={total_labels} skipped_empty_substance={skipped_empty_substance} molecules={len(molecules)}")

# Save a checkpoint of aggregates so later write stages can run independently if needed.
# (Writing stages are below; no checkpoint persistence needed.)

# ---- normalize helper for legal comparison ----
def norm_ws(s):
    return " ".join(s.split()).strip()

# ---- 4+5. build records and write artifacts ----
import openpyxl
from openpyxl import Workbook

jsonl_path = os.path.join(TESTBED, "molecules.jsonl")
xlsx_path = os.path.join(TESTBED, "molecules.xlsx")
legal_path = os.path.join(TESTBED, "legal_pairs.xlsx")
manifest_path = os.path.join(TESTBED, "MANIFEST.json")

counts = {
    "total_labels_parsed": total_labels,
    "labels_skipped_empty_substance": skipped_empty_substance,
    "total_distinct_molecules": len(molecules),
    "molecules_with_indications": 0,
    "molecules_without_indications": 0,
    "testbed_brand_only": 0,
    "testbed_generic_only": 0,
    "testbed_both_brand_and_generic": 0,
    "testbed_other_only": 0,
    "testbed_molecules_with_http_in_indications": 0,
}
http_examples = []

# deterministic order: sort molecules by their substance key tuple
ordered_keys = sorted(molecules.keys())

# xlsx workbooks
wb = Workbook()
ws = wb.active
ws.title = "molecules"
ws.append(["molecule_key", "n_labels", "n_brand", "n_generic", "has_brand",
           "has_generic", "rxcuis", "indications_text", "prose_truncated"])

legal_wb = Workbook()
lws = legal_wb.active
lws.title = "legal_pairs"
lws.append(["molecule", "brand_indications", "generic_indications", "flag"])

TRUNC = 32000
CELL_MAX = 32000  # also cap legal cells for xlsx safety

def build_molecule_record(key, m):
    distinct = m["distinct_prose"]
    labels = m["labels"]
    n_labels = len(labels)
    n_brand = sum(1 for l in labels if l["kind"] == "brand")
    n_generic = sum(1 for l in labels if l["kind"] == "generic")
    has_brand = n_brand > 0
    has_generic = n_generic > 0
    has_indications = len(distinct) > 0
    display_name = " + ".join(m["substances"])
    indications_text = "\n\n".join(distinct)
    rxcuis = sorted(m["rxcuis"])
    label_entries = []
    for l in labels:
        pi = l["prose_idx"]
        label_entries.append({
            "application_number": l["application_number"],
            "kind": l["kind"],
            "indications_text": distinct[pi] if pi >= 0 else "",
        })
    rec = {
        "molecule_key": m["substances"],
        "display_name": display_name,
        "indications_text": indications_text,
        "rxcuis": rxcuis,
        "n_labels": n_labels,
        "labels": label_entries,
        "n_brand": n_brand,
        "n_generic": n_generic,
        "has_brand": has_brand,
        "has_generic": has_generic,
        "has_indications": has_indications,
    }
    return rec

log("Writing molecules.jsonl + xlsx ...")
with open(jsonl_path, "w", encoding="utf-8") as jf:
    for key in ordered_keys:
        m = molecules[key]
        rec = build_molecule_record(key, m)
        if not rec["has_indications"]:
            counts["molecules_without_indications"] += 1
            continue
        # test bed member
        counts["molecules_with_indications"] += 1
        # kind breakdown over test bed
        if rec["has_brand"] and rec["has_generic"]:
            counts["testbed_both_brand_and_generic"] += 1
        elif rec["has_brand"]:
            counts["testbed_brand_only"] += 1
        elif rec["has_generic"]:
            counts["testbed_generic_only"] += 1
        else:
            counts["testbed_other_only"] += 1
        # http scan
        if "http://" in rec["indications_text"]:
            counts["testbed_molecules_with_http_in_indications"] += 1
            if len(http_examples) < 8:
                # extract a short snippet around http://
                t = rec["indications_text"]
                p = t.find("http://")
                snippet = t[p:p + 80].split()[0]
                http_examples.append({"molecule": rec["display_name"], "url": snippet})
        # write jsonl
        jf.write(json.dumps(rec, ensure_ascii=False) + "\n")
        # xlsx row
        ind = rec["indications_text"]
        truncated = len(ind) > TRUNC
        cell = ind[:TRUNC] if truncated else ind
        ws.append([rec["display_name"], rec["n_labels"], rec["n_brand"],
                   rec["n_generic"], rec["has_brand"], rec["has_generic"],
                   ",".join(rec["rxcuis"])[:CELL_MAX], cell, truncated])
        # legal pairs
        if rec["has_brand"] and rec["has_generic"]:
            brand_prose, generic_prose = [], []
            bseen, gseen = set(), set()
            for le in rec["labels"]:
                it = le["indications_text"]
                if not it:
                    continue
                if le["kind"] == "brand" and it not in bseen:
                    bseen.add(it); brand_prose.append(it)
                elif le["kind"] == "generic" and it not in gseen:
                    gseen.add(it); generic_prose.append(it)
            bset = set(norm_ws(x) for x in brand_prose if norm_ws(x))
            gset = set(norm_ws(x) for x in generic_prose if norm_ws(x))
            if bset == gset:
                flag = "identical"
            elif gset and gset.issubset(bset):
                flag = "generic_subset_of_brand"
            else:
                flag = "divergent"
            btext = "\n\n".join(brand_prose)
            gtext = "\n\n".join(generic_prose)
            lws.append([rec["display_name"], btext[:CELL_MAX], gtext[:CELL_MAX], flag])

log("Saving xlsx files ...")
wb.save(xlsx_path)
legal_wb.save(legal_path)

# ---- sha256 of jsonl ----
h = hashlib.sha256()
with open(jsonl_path, "rb") as f:
    for chunk in iter(lambda: f.read(1024 * 1024), b""):
        h.update(chunk)
jsonl_sha = h.hexdigest()

# ---- manifest ----
MOLECULE_KEY_RULE = (
    "molecule_key = tuple(sorted(set(s.strip().upper() for s in openfda.substance_name "
    "if s and s.strip()))). Each distinct set of substances is one molecule; a combination "
    "product (multiple substances) is its own molecule. Labels with no non-empty "
    "substance_name are skipped and counted. display_name = ' + '.join(molecule_key). "
    "kind per label: 'generic' if any application_number starts 'ANDA' (checked first); "
    "else 'brand' if any starts 'NDA' or 'BLA'; else 'other'. A label's indications prose = "
    "' '.join(indications_and_usage list), stripped. A molecule's indications_text = the "
    "distinct (byte-identical dedup) non-empty label proses joined with '\\n\\n', in order "
    "of first appearance across the full partition scan (partitions processed 1..14 in index "
    "order, records in file order). NOTE: proper RxNorm-ingredient normalization "
    "(salt/form folding) is a DEFERRED upgrade (O2) and is NOT applied here."
)
LEGAL_RULE = (
    "legal_pairs includes only molecules with has_brand AND has_generic. brand_indications = "
    "union (first-appearance, byte-identical dedup) of indications prose across the molecule's "
    "brand-kind labels; generic_indications = same across generic-kind labels. Comparison is on "
    "SETS of whitespace-collapsed prose strings (norm = ' '.join(s.split()).strip()), empty "
    "strings dropped: flag='identical' if the brand set equals the generic set; "
    "'generic_subset_of_brand' if the generic set is non-empty and a subset of the brand set; "
    "else 'divergent'. Best-effort string comparison, no semantic matching."
)

manifest = {
    "source": "openFDA drug/label bulk download",
    "download_index": INDEX_URL,
    "export_date": export_date,
    "total_records_reported": total_records,
    "built_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    "partitions": partition_meta,
    "partition_processing_report": partition_report,
    "molecule_key_rule": MOLECULE_KEY_RULE,
    "legal_comparison_rule": LEGAL_RULE,
    "counts": counts,
    "http_examples": http_examples,
    "artifacts": {
        "molecules_jsonl": "molecules.jsonl",
        "molecules_xlsx": "molecules.xlsx",
        "legal_pairs_xlsx": "legal_pairs.xlsx",
    },
    "molecules_jsonl_sha256": jsonl_sha,
}
with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2, ensure_ascii=False)

log("MANIFEST written.")
log("COUNTS: " + json.dumps(counts, indent=2))
log(f"jsonl sha256: {jsonl_sha}")
print("BUILD_COMPLETE", flush=True)
