# Copyright (c) 2026 ChatHealthy.ai LLC. All rights reserved.
# Licensed under the FindCare Evaluation License (FEL-1.0).

"""Pass-3 pseudo-production runner (Test Plan V11 section 11 + section 5).

THE DRIVER (test code, V11 section 13). It imports the PRODUCTION tool
(FDADrugEnrichmentTool) from the pipeline codebase and runs it over the
Test-bed-2 sample (750 SPLs) the way production will, for the single
candidate gpt-5.6-luna.

What this program does and does not do, per V11:

  * CANDIDATE ONLY -- gpt-5.6-luna (section 11). No other model is run here.
  * INPUTS READ FROM STAGING -- the 750 drug records are READ from the pipeline
    cluster's VERSIONED openFDA-label staging collection in MongoDB (NOT from the
    frozen .jsonl). The collection name is resolved through the dataset registry
    at the LIVE data_version exactly as the pipeline engines resolve it (db
    PublicStaging, collection StagingOpenFdaLabels_v_{data_version}); the version
    is never hardcoded. Each staging document wraps the openFDA label under a
    top-level `raw` field; the input records the tool needs (set_id, molecule,
    indication_text, openfda.rxcui) are unwrapped from raw.set_id,
    raw.openfda.substance_name/generic_name, raw.indications_and_usage, and
    raw.openfda.rxcui. The bed2 .jsonl identifies WHICH 750 SPLs to pull.
  * RESOLVE FIRST, THEN CROSSWALK -- for each batch the tool's PROMPT 1
    (resolve_rxcuis) runs first, then PROMPT 2 (crosswalk). The resolved rxcui
    is inserted into PROMPT 2's input only when its resolution confidence
    exceeds the tool's own insert threshold (_INSERT_THRESHOLD). Batch size 50.
  * TWO CROSSWALK ARMS -- "insert" (production-faithful: rxcui inserted above
    the threshold) and "bare" (rxcui never inserted). V11 section 12 requires
    measuring crosswalk quality WITH vs WITHOUT the inserted rxcui, which can
    only be done by running both arms over the same inputs.
  * record_number -- assigned 1..750 by the record's position in the ordered
    sample (Appendix B: record_number is the sequential processing index, "only
    how the file is divided across workers" -- a position, not a completion
    order, so it is deterministic under the thread fan-out).
  * FAN-OUT -- a thread pool of 5 over the 15 batches (threads, not processes;
    real process fan-out is out of scope, V11 section 11).
  * MONGO WHERE WE JOIN, SCRATCH WHERE WE DO NOT -- the staging drug records are
    read in ONE $in query and the resolution<->crosswalk match is done in memory;
    NO index is built (Amendment 4: production-scale indexing is out of run-3
    scope). The resolution records are written to a clearly-named unversioned test
    working collection; the write-once/read-once raw model outputs (PROMPT 1 and
    PROMPT 2 results) stay on local scratch disk.
  * PERSIST-FIRST -- this runner does nothing but fire and write each raw result
    atomically; a SEPARATE scorer (pass3_score.py) reads those files and judges,
    so no paid result can be discarded by a processing bug. Resumable: a batch
    whose scratch files are already complete is reused, never re-fired.
  * RETEST ON DROP -- if the crosswalk omits any input id in a batch, the dropped
    ids only are refired (bounded rounds); the drop and whether the retest
    recovered it are both recorded (section 5).

NOTHING FIRES ON IMPORT. No model call, no RxNav call, and no MongoDB connection
happens at import or construction -- only inside run(), which the operator
authorizes end to end (model calls cost money; the cluster must be awake).
"""

from __future__ import annotations

import concurrent.futures
import datetime
import json
import os
import pathlib
import sys
import threading
import time

# ─────────────────────────────────────────────────────────────────────────────
# Make the production tool and the shared library importable.
# ─────────────────────────────────────────────────────────────────────────────
_ROOT = pathlib.Path(r"c:\CHATHealthyLLC")
_PIPELINE_DIR = _ROOT / "pipeline" / "MedicareProviderEvaluationDataPipeline"
_LIB_SRC = _ROOT / "ChatHealthyLib" / "src"
for _p in (str(_ROOT), str(_LIB_SRC), str(_PIPELINE_DIR)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from chathealthy_lib.exceptions import ChatHealthyException
from chathealthy_lib.logging_service import ChatHealthyLoggingService
from chathealthy_lib.mongo_utilities import ChatHealthyMongoUtilities

# Staging collection names are resolved through the dataset registry at the live
# data_version, exactly as the pipeline engines resolve them (PipelineRuntime).
from pipeline.run_lifecycle.pipeline_config import load_pipeline_config
from pipeline.run_lifecycle.pipeline_dataset_registry import PipelineDatasetRegistry

# THE TOOL -- imported, never reimplemented (V11 section 13).
import fda_drug_enrichment_tool as tool_module
from fda_drug_enrichment_tool import FDADrugEnrichmentTool

_log = ChatHealthyLoggingService()

# ─────────────────────────────────────────────────────────────────────────────
# Candidate and sample (V11 section 11).
# ─────────────────────────────────────────────────────────────────────────────
CANDIDATE_MODEL = "gpt-5.6-luna"            # section 11: the candidate, and only it

HARNESS = _ROOT / "_oneshots" / "medicare_benchmark" / "harness"
BED2_PATH = HARNESS / "benchmark_sample_v2.jsonl"   # identifies WHICH 750 SPLs
CATALOG_PATH = _ROOT / "_oneshots" / "medicare_benchmark" / "icd10_categories_top3levels.xlsx"
SCRATCH_DIR = HARNESS / "pass3_scratch"             # local write-once/read-once raw outputs

BATCH = 50                                   # the production batch size (section 5)
THREADS = 5                                  # section 11 fan-out: 5 threads over 750
MAX_RETEST_ROUNDS = 3                        # bounded retest-on-drop (section 5)
EXPECTED_SAMPLE_SIZE = 750                   # Test bed 2 (section 4)

# ─────────────────────────────────────────────────────────────────────────────
# STAGING INPUT -- the pipeline cluster's VERSIONED openFDA-label staging
# collection, resolved through the dataset registry at the live data_version.
#
# The 750 input records are read from db PublicStaging, collection
# StagingOpenFdaLabels_v_{data_version}, on the ChatHealthyDataPipelines cluster.
# The collection name is resolved through PipelineDatasetRegistry exactly as the
# pipeline engines resolve it; the version is never hardcoded (it is the live
# data_version read from the environment the way the control runner reads it).
# ─────────────────────────────────────────────────────────────────────────────
STAGING_SOURCE_NAME = "openfda_labels"   # dataset_versions[] source_name in pipeline_config.json
PIPELINE_ENV = "dev"                     # the harness is a dev-local pass-3 tool

# How the 750 bed2 rows select their staging SPLs. bed2 as frozen carries NO set_id
# and NO openfda.rxcui (confirmed: build_testbed.py never captured set_id; its
# fields are molecule_id, molecule_key, n_children, child_index, kind,
# application_number, indication_text). The only SPL-facing identity bed2 holds is
# the FDA application_number(s) plus the derived kind, so the selector is
# (frozenset(application_number), kind) -- the operator's named example.
#
# FLAGGED AMBIGUOUS (Amendment 2 escalate clause): one application_number covers
# MANY SPLs (set_ids), so this selector is one-to-many BY CONSTRUCTION. The join
# in fetch_and_stage_inputs REQUIRES exactly one staging SPL per selector and
# escalates via ChatHealthyException otherwise. Unless staging happens to hold
# exactly one SPL per (application_number set, kind) for these 750, the run cannot
# pull SPL-faithful records until a 1:1 bed2->SPL mapping is supplied (e.g. set_id
# frozen into the sample). Nothing is guessed and nothing is silently collapsed.
STAGING_APPLICATION_NUMBER_FIELD = "raw.openfda.application_number"

# Clearly-named UNVERSIONED test/working collection -- NEVER production staging.
# The selected staging records are copied here (no index -- Amendment 4); the
# resolution records (keyed to each drug) are written here (no index).
WORKING_STAGING_COLLECTION = "pass3_test_working_staging"
WORKING_RESOLUTION_COLLECTION = "pass3_test_working_resolution"


# ─────────────────────────────────────────────────────────────────────────────
# Scratch persistence (atomic, resumable).
# ─────────────────────────────────────────────────────────────────────────────
def _persist_atomic(path: pathlib.Path, record: dict) -> None:
    """Write record to path atomically (tmp then os.replace). Persist-first:
    the paid raw output lands on disk before anything reads or scores it."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".partial")
    tmp.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _complete_ids(path: pathlib.Path) -> set:
    """The set of result ids a persisted scratch file already carries, or empty
    if unreadable/absent -- the resume test."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        out = data.get("output") or {}
        return {str(r.get("id")) for r in (out.get("results") or [])}
    except Exception:  # noqa: BLE001  -- an unreadable scratch file is simply re-fired
        return set()


def _p1_path(batch_index: int) -> pathlib.Path:
    return SCRATCH_DIR / f"p3__b{batch_index:02d}__prompt1.json"


def _p2_path(batch_index: int, arm: str) -> pathlib.Path:
    return SCRATCH_DIR / f"p3__b{batch_index:02d}__prompt2_{arm}.json"


def _now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


# Per-call token/retry usage is captured from the tool's public accessors
# (last_resolution_usage / last_crosswalk_usage) and accumulated across retest
# rounds onto each raw envelope, so the scorer can cost the run (section 8).
def _new_usage_acc() -> dict:
    return {"available": True, "input_tokens": 0, "output_tokens": 0,
            "cached_input_tokens": 0, "transient_retries": 0, "model_calls": 0,
            "model_call_fired": False}


def _add_usage(acc: dict, usage) -> None:
    """Fold one per-call usage dict (from the tool) into a running accumulator."""
    if not usage:
        return
    acc["model_calls"] += 1
    if usage.get("model_call_fired", True):
        acc["model_call_fired"] = True
    for field in ("input_tokens", "output_tokens", "cached_input_tokens", "transient_retries"):
        value = usage.get(field)
        if isinstance(value, (int, float)):
            acc[field] += value
    if usage.get("usage_error"):
        acc.setdefault("usage_errors", []).append(usage["usage_error"])


# ─────────────────────────────────────────────────────────────────────────────
# Mongo -- read staging directly (unversioned), one $in query, match in memory.
# ─────────────────────────────────────────────────────────────────────────────
def _working_db_name(client) -> str:
    """The database the clearly-named TEST working collections live in -- NOT the
    real staging database (that is PublicStaging, read directly). CH_PIPELINE_DB
    is a deployed fact with no default; sentinel-flagged if unset."""
    name = os.environ.get("CH_PIPELINE_DB", "").strip()
    if not name:
        raise ChatHealthyException(
            mode="config_error",
            component="pass3_run",
            message=("CH_PIPELINE_DB is not set: the database holding the Pass-3 test working "
                     "collections is a deployed fact and has no default. Set it before the run."),
        )
    return name


def _get_staging_client():
    """One mTLS handle to the pipeline cluster as pipelineEditor -- a pipeline run,
    not an ad-hoc action. Rule-065 statement 10: identity and cluster are BOTH
    hardcoded string literals."""
    return ChatHealthyMongoUtilities().getConnection(
        "pipelineEditor", "ChatHealthyDataPipelines")


def _live_data_version() -> int:
    """The live pipeline data_version, read from DATA_VERSION the same way the
    control runner reads it (control_runner.py). Never hardcoded; it is a deployed
    run fact. If it cannot be resolved the staging name cannot be resolved, so the
    run escalates rather than guess a generation."""
    raw = os.environ.get("DATA_VERSION", "").strip()
    if not raw.isdigit() or int(raw) < 1:
        raise ChatHealthyException(
            mode="config_error",
            component="pass3_run",
            message=("DATA_VERSION is not set to a positive integer; the live pipeline "
                     "data_version is a deployed run fact resolved from the environment the way "
                     "the control runner reads it, never hardcoded. Set DATA_VERSION to the live "
                     "generation (currently 1) before the run."),
        )
    return int(raw)


def _staging_registry(client) -> PipelineDatasetRegistry:
    """The dataset registry at the live data_version, built from the brain pipeline
    config exactly as the pipeline engines build it (PipelineRuntime.registry). The
    versioned staging collection name is resolved off this registry."""
    cfg = load_pipeline_config(env_prefix=PIPELINE_ENV)
    return PipelineDatasetRegistry(cfg, _live_data_version(), client)


def load_bed2() -> list:
    """Read bed2; return the 750 rows in file order (position = record_number-1)."""
    rows = [json.loads(line) for line in BED2_PATH.read_text(encoding="utf-8").splitlines()
            if line.strip()]
    if len(rows) != EXPECTED_SAMPLE_SIZE:
        _log.LogPipeline(
            "WARNING",
            "pass3_run: bed2 holds %d rows, expected %d (section 4). Proceeding with the file.",
            len(rows), EXPECTED_SAMPLE_SIZE)
    return rows


def _derive_kind(application_numbers) -> str:
    """brand / generic / other from a label's application_number list, by the SAME
    rule the test-bed builder used (build_testbed.classify_kind): ANDA -> generic
    (checked first), NDA/BLA -> brand, else other. Used to match a bed2 row's kind."""
    anda = brandish = False
    for a in application_numbers or []:
        au = str(a).strip().upper()
        if au.startswith("ANDA"):
            anda = True
        elif au.startswith("NDA") or au.startswith("BLA"):
            brandish = True
    if anda:
        return "generic"
    if brandish:
        return "brand"
    return "other"


def _bed2_selector(row: dict) -> tuple:
    """The (frozenset(application_number), kind) a bed2 row selects on. This is the
    documented selector (Amendment 2): bed2 carries no set_id, so an SPL is
    addressed by its FDA application_number(s) plus the derived kind. Missing
    application_number/kind is fatal -- the row cannot be joined to staging."""
    app_numbers = row.get("application_number") or []
    if isinstance(app_numbers, str):
        app_numbers = [app_numbers]
    kind = str(row.get("kind") or "").strip()
    if not app_numbers or not kind:
        raise ChatHealthyException(
            mode="value_error",
            component="pass3_run",
            message=(f"bed2 row carries no application_number/kind to select a staging SPL; "
                     f"row keys present: {sorted(row)}"),
        )
    return (frozenset(str(a).strip().upper() for a in app_numbers), kind)


def _extract_staging_record(doc: dict, record_id: str) -> dict:
    """Unwrap one staging openFDA-label document (label under `raw`) into the top-
    level shape the tool's key extractor reads: id, set_id (raw.set_id), molecule
    (joined raw.openfda.substance_name, else generic_name), indication_text (joined
    raw.indications_and_usage), and openfda.rxcui (raw.openfda.rxcui)."""
    raw = doc.get("raw") or {}
    openfda = raw.get("openfda") or {}
    set_id = str(raw.get("set_id") or "").strip()
    substances = openfda.get("substance_name") or []
    if isinstance(substances, str):
        substances = [substances]
    generic = openfda.get("generic_name") or []
    if isinstance(generic, str):
        generic = [generic]
    molecule = " + ".join(s.strip() for s in substances if s and s.strip())
    if not molecule:
        molecule = " + ".join(g.strip() for g in generic if g and g.strip())
    iau = raw.get("indications_and_usage") or []
    if isinstance(iau, str):
        iau = [iau]
    indication_text = " ".join(x for x in iau if x).strip()
    rxcui = [str(v).strip() for v in (openfda.get("rxcui") or []) if str(v).strip()]
    return {"id": record_id, "set_id": set_id, "molecule": molecule,
            "indication_text": indication_text, "openfda": {"rxcui": rxcui}}


def fetch_and_stage_inputs(bed2_rows: list) -> list:
    """Read the 750 staging SPLs the bed2 rows select, in ONE $in query against the
    unversioned PublicStaging.StagingOpenFdaLabels, match each bed2 row to its SPL
    in memory on (application_number set, kind), unwrap each to the tool's input
    shape, and return them aligned to bed2 order (position -> record_number). No
    index is built (Amendment 4). The selected records are also copied, UNINDEXED,
    into the clearly-named test working collection (never production staging).

    A bed2 selector that matches zero or MORE THAN ONE staging SPL is fatal -- the
    selector is one-to-many by construction (bed2 lacks set_id), so an ambiguous
    match is escalated rather than silently collapsed (Amendment 2 escalate clause)."""
    client = _get_staging_client()
    registry = _staging_registry(client)
    entry = registry.by_source_name(STAGING_SOURCE_NAME)
    staging_db = entry.staging_db
    staging_coll_name = registry.staging_collection_name(STAGING_SOURCE_NAME)
    staging = client[staging_db][staging_coll_name]

    selectors = [_bed2_selector(r) for r in bed2_rows]
    all_app_numbers = sorted({a for sel in selectors for a in sel[0]})
    # One $in query over every application_number the 750 rows name -- a single
    # scan, fine at this scale (Amendment 4). No index created or required.
    by_selector: dict = {}
    for doc in staging.find({STAGING_APPLICATION_NUMBER_FIELD: {"$in": all_app_numbers}}):
        openfda = (doc.get("raw") or {}).get("openfda") or {}
        app_numbers = openfda.get("application_number") or []
        if isinstance(app_numbers, str):
            app_numbers = [app_numbers]
        key = (frozenset(str(a).strip().upper() for a in app_numbers),
               _derive_kind(app_numbers))
        by_selector.setdefault(key, []).append(doc)

    ordered: list = []
    missing: list = []
    ambiguous: list = []
    for pos, sel in enumerate(selectors):
        matches = by_selector.get(sel) or []
        if len(matches) == 0:
            missing.append((pos, sorted(sel[0]), sel[1]))
        elif len(matches) > 1:
            ambiguous.append((pos, sorted(sel[0]), sel[1], len(matches)))
        else:
            ordered.append(_extract_staging_record(matches[0], str(pos)))
    if missing:
        raise ChatHealthyException(
            mode="value_error",
            component="pass3_run",
            message=(f"{len(missing)} of {len(selectors)} bed2 selectors matched no staging SPL "
                     f"in {staging_db}.{staging_coll_name} on (application_number set + kind); "
                     f"first: {missing[0]}."),
        )
    if ambiguous:
        raise ChatHealthyException(
            mode="value_error",
            component="pass3_run",
            message=(f"{len(ambiguous)} of {len(selectors)} bed2 selectors matched MORE THAN ONE "
                     f"staging SPL on (application_number set + kind). The selector is ambiguous "
                     f"because bed2 carries no set_id (build_testbed.py never captured it) and one "
                     f"application_number covers many SPLs. first: {ambiguous[0]}. Supply a 1:1 "
                     f"bed2->SPL mapping (e.g. freeze set_id into the sample) before Pass 3 can "
                     f"pull SPL-faithful records."),
        )

    # Copy into the clearly-named working collection (UNINDEXED -- Amendment 4).
    # Replace each by set_id so a resumed run is idempotent.
    working = client[_working_db_name(client)][WORKING_STAGING_COLLECTION]
    for rec in ordered:
        working.replace_one({"set_id": rec["set_id"]}, rec, upsert=True, idempotent=True)
    _log.LogPipeline("INFO", "pass3_run: staged %d records from %s.%s into %s (no index)",
                     len(ordered), staging_db, staging_coll_name, WORKING_STAGING_COLLECTION)
    return ordered


def _resolution_collection():
    """The clearly-named test working collection for resolution records. No index
    is built (Amendment 4); the resolution<->crosswalk match is done in memory."""
    client = _get_staging_client()
    return client[_working_db_name(client)][WORKING_RESOLUTION_COLLECTION]


# ─────────────────────────────────────────────────────────────────────────────
# One batch: PROMPT 1 (resolve) -> both crosswalk arms (PROMPT 2), persist-first.
# ─────────────────────────────────────────────────────────────────────────────
def _insert_decision(resolution_item) -> bool:
    """The tool's own insert rule, reused verbatim (not reinvented): insert the
    resolved ingredient rxcui array into the crosswalk input only when it is
    non-empty and its resolution confidence exceeds the tool's threshold."""
    return (bool(resolution_item.ingredient_rxcuis)
            and resolution_item.confidence > tool_module._INSERT_THRESHOLD)


def _resolve_with_retest(tool: FDADrugEnrichmentTool, keys: list):
    """Fire PROMPT 1 resolution, refiring only the ids the tier-3 model DROPPED
    (floored with the tool's drop sentinel, distinct from an honest decline) for
    bounded rounds -- the resolution-leg mirror of _crosswalk_with_retest
    (section 5). An exhausted-retry ChatHealthyException is RECORDED and ends the
    rounds, never crashing the run (section 5 'recorded as errored, never
    fabricated'). Returns
    (resolution_by_id, rounds_log, dropped_after_retest, usage_acc, fatal_error)."""
    resolution_by_id: dict = {}
    rounds_log: list = []
    usage_acc = _new_usage_acc()
    by_id = {k.id: k for k in keys}
    remaining_ids = [k.id for k in keys]
    fatal_error = None
    for rnd in range(0, MAX_RETEST_ROUNDS + 1):
        if not remaining_ids:
            break
        fire = [by_id[i] for i in remaining_ids]
        error = None
        dropped_ids: list = []
        resolved_ids: list = []
        try:
            resolution = tool.resolve_rxcuis(fire)
            _add_usage(usage_acc, tool.last_resolution_usage())
            for item in resolution.results:
                resolution_by_id[item.id] = item
                if (item.resolved_by == "floor"
                        and item.confidence_rationale == tool_module._RESOLUTION_DROP_RATIONALE):
                    dropped_ids.append(item.id)
                else:
                    resolved_ids.append(item.id)
        except ChatHealthyException as exc:
            error = repr(exc)[:500]
            fatal_error = error
            dropped_ids = [k.id for k in fire]
        rounds_log.append({"round": rnd, "fired_ids": [k.id for k in fire],
                           "resolved_or_declined_ids": sorted(resolved_ids),
                           "dropped_ids": sorted(dropped_ids), "error": error})
        if error is not None:
            break
        remaining_ids = sorted(dropped_ids)
    return resolution_by_id, rounds_log, sorted(remaining_ids), usage_acc, fatal_error


def _crosswalk_with_retest(tool: FDADrugEnrichmentTool, drug_inputs: list, label: str):
    """Fire PROMPT 2 for one arm, refiring only dropped ids for bounded rounds.
    Returns (merged_results_by_id, rounds_log, dropped_after_retest, usage_acc)."""
    merged: dict = {}
    rounds_log: list = []
    usage_acc = _new_usage_acc()
    expected = {d.id for d in drug_inputs}
    by_id = {d.id: d for d in drug_inputs}
    remaining = set(expected)
    for rnd in range(0, MAX_RETEST_ROUNDS + 1):
        if not remaining:
            break
        fire = drug_inputs if rnd == 0 else [by_id[i] for i in sorted(remaining)]
        batch_in = tool_module.CrosswalkBatchInput(drugs=fire)
        error = None
        got: set = set()
        try:
            output = tool.crosswalk(batch_in)
            _add_usage(usage_acc, tool.last_crosswalk_usage())
            for result in output.results:
                merged[result.id] = result.model_dump()
                got.add(result.id)
        except ChatHealthyException as exc:
            error = repr(exc)[:500]
        remaining -= got
        rounds_log.append({"round": rnd, "arm": label, "fired_ids": [d.id for d in fire],
                           "returned_ids": sorted(got), "error": error})
        if error is not None:
            break
    return merged, rounds_log, sorted(remaining), usage_acc


def process_batch(batch_index: int, keys: list, records_by_id: dict,
                  resolution_coll_factory) -> tuple:
    """Fire PROMPT 1 then both PROMPT-2 arms for one batch; persist each raw
    result atomically; write the keyed resolution records to the indexed Mongo
    working collection. Resume-aware per scratch file. Returns a short status."""
    tool = FDADrugEnrichmentTool(model=CANDIDATE_MODEL, catalog=str(CATALOG_PATH))

    # ---- PROMPT 1: resolution (fires RxNav; a model call only if a residue exists)
    p1_path = _p1_path(batch_index)
    t0 = time.monotonic()
    resolution_by_id: dict = {}
    if p1_path.exists() and _complete_ids(p1_path):
        data = json.loads(p1_path.read_text(encoding="utf-8"))
        for item in (data.get("output") or {}).get("results") or []:
            resolution_by_id[str(item["id"])] = tool_module.RxcuiResolutionItem(**item)
    else:
        (resolution_by_id, p1_rounds, p1_dropped,
         p1_usage, p1_error) = _resolve_with_retest(tool, keys)
        complete = set(resolution_by_id) >= {k.id for k in keys}
        ordered = [resolution_by_id[k.id].model_dump() for k in keys if k.id in resolution_by_id]
        _persist_atomic(p1_path, {
            "phase": "prompt1_resolution", "batch_index": batch_index,
            "model": CANDIDATE_MODEL, "timestamp_utc": _now_iso(),
            "input_ids": [k.id for k in keys],
            "id_to_set_id": {k.id: k.set_id for k in keys},
            "id_to_record_number": {k.id: records_by_id[k.id]["record_number"] for k in keys},
            "rounds": p1_rounds,
            "dropped_after_retest": p1_dropped,
            "errored": (not complete),
            "error": p1_error,
            "output": {"results": ordered},
            "elapsed_seconds": round(time.monotonic() - t0, 3),
            "usage": p1_usage,
        })
        if not complete:
            # Recorded as errored; do not fabricate a crosswalk over a resolution
            # we do not have (section 5). The batch re-fires on a resumed run.
            _log.LogPipeline(
                "WARNING",
                "pass3_run: batch %d PROMPT 1 resolution errored; recorded, crosswalk skipped",
                batch_index)
            return (batch_index, {"batch_index": batch_index, "dropped": {},
                                  "resolution_errored": True})
        # Resolution records (keyed to each drug) -> indexed Mongo working collection.
        coll = resolution_coll_factory()
        for key in keys:
            item = resolution_by_id[key.id]
            doc = item.model_dump()
            doc["set_id"] = key.set_id
            doc["record_number"] = records_by_id[key.id]["record_number"]
            coll.replace_one({"id": item.id, "set_id": key.set_id}, doc,
                             upsert=True, idempotent=True)

    # ---- Build the two crosswalk arms over the same inputs (section 12).
    insert_inputs, bare_inputs = [], []
    for key in keys:
        item = resolution_by_id[key.id]
        insert = _insert_decision(item)
        insert_inputs.append(tool_module.DrugInput(
            id=key.id, set_id=key.set_id, molecule=key.molecule,
            rxcui=list(item.ingredient_rxcuis) if insert else [],
            indication_text=key.indication_text))
        bare_inputs.append(tool_module.DrugInput(
            id=key.id, set_id=key.set_id, molecule=key.molecule,
            rxcui=[], indication_text=key.indication_text))

    status = {"batch_index": batch_index, "dropped": {}}
    for arm, inputs in (("insert", insert_inputs), ("bare", bare_inputs)):
        p2_path = _p2_path(batch_index, arm)
        if p2_path.exists() and _complete_ids(p2_path) >= {d.id for d in inputs}:
            status["dropped"][arm] = []
            continue
        t_arm = time.monotonic()
        merged, rounds_log, dropped, arm_usage = _crosswalk_with_retest(tool, inputs, arm)
        _persist_atomic(p2_path, {
            "phase": "prompt2_crosswalk", "arm": arm, "batch_index": batch_index,
            "model": CANDIDATE_MODEL, "timestamp_utc": _now_iso(),
            "insert_threshold": tool_module._INSERT_THRESHOLD,
            "input_ids": [d.id for d in inputs],
            "id_to_set_id": {d.id: d.set_id for d in inputs},
            "id_to_record_number": {d.id: records_by_id[d.id]["record_number"] for d in inputs},
            "inserted_rxcui_ids": sorted(d.id for d in inputs if d.rxcui),
            "rounds": rounds_log,
            "dropped_after_retest": dropped,
            "output": {"results": list(merged.values())},
            "elapsed_seconds": round(time.monotonic() - t_arm, 3),
            "usage": arm_usage,
        })
        status["dropped"][arm] = dropped
    return (batch_index, status)


# ─────────────────────────────────────────────────────────────────────────────
# Orchestration.
# ─────────────────────────────────────────────────────────────────────────────
def run() -> None:
    """Fire Pass 3 end to end. Operator-authorized: makes model calls, hits RxNav,
    and connects to MongoDB. The cluster is assumed already awake (the operator
    wakes it); this program builds its indexes and runs."""
    SCRATCH_DIR.mkdir(parents=True, exist_ok=True)
    _log.LogPipeline("INFO", "pass3_run: candidate=%s batch=%d threads=%d scratch=%s",
                     CANDIDATE_MODEL, BATCH, THREADS, SCRATCH_DIR)

    bed2_rows = load_bed2()
    staging_records = fetch_and_stage_inputs(bed2_rows)   # reads staging, builds indexed working copy

    # Build the tool once only to use its faithful key extractor; model/agent are
    # built lazily and per-batch (no network here).
    key_tool = FDADrugEnrichmentTool(model=CANDIDATE_MODEL, catalog=str(CATALOG_PATH))
    keys = [key_tool._extract_key(rec, pos) for pos, rec in enumerate(staging_records)]
    records_by_id = {}
    for pos, key in enumerate(keys):
        records_by_id[key.id] = {"record_number": pos + 1, "set_id": key.set_id, "position": pos}

    # Ensure the resolution working collection exists and is indexed up front.
    _resolution_collection()

    batches = [keys[i:i + BATCH] for i in range(0, len(keys), BATCH)]
    _log.LogPipeline("INFO", "pass3_run: %d records -> %d batches of <=%d",
                     len(keys), len(batches), BATCH)

    results: list = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=THREADS) as pool:
        futures = [pool.submit(process_batch, bi, batch, records_by_id, _resolution_collection)
                   for bi, batch in enumerate(batches)]
        for fut in concurrent.futures.as_completed(futures):
            bi, status = fut.result()
            results.append(status)
            dropped = {a: d for a, d in status["dropped"].items() if d}
            _log.LogPipeline("INFO", "pass3_run: batch %d done%s", bi,
                             f" DROPPED={dropped}" if dropped else "")

    _log.LogPipeline("INFO", "pass3_run: DONE. batches=%d scratch=%s. Run pass3_score.py to judge.",
                     len(results), SCRATCH_DIR)


if __name__ == "__main__":
    run()
